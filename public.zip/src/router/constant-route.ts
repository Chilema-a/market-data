import { i18n } from '@/global/register-i18n'
import { RouteRecordRaw } from 'vue-router'
import Layout from '@/views/layout/layout.vue'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    name: 'layout',
    component: Layout,
  },
  {
    path: '/login',
    name: 'login',
    meta: {
      titleKey: 'navigation.login',
      get title() {
        return i18n.global.t('navigation.login')
      },
    },
    component: () => import('../views/login/login.vue'),
  },
]
export default routes
