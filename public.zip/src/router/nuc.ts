import { i18n } from '@/global/register-i18n'
import { RouteRecordRaw } from 'vue-router'

import CustomerList from '@/views/nuc/customer-list/customer-list.vue'
import LoginLog from '@/views/nuc/login-log/login-log.vue'
import TradeLoginLog from '@/views/nuc/trade-login-log/trade-login-log.vue'
import RiskList from '@/views/nuc/risk-list/risk-list.vue'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/internet/customer/list',
    name: 'internet-customer-list',
    meta: {
      titleKey: 'navigation.internet_accounts',
      get title() {
        return i18n.global.t('navigation.internet_accounts')
      },
    },
    component: CustomerList,
  },
  {
    path: '/internet/customer/login-log',
    name: 'internet-customer-login-log',
    meta: {
      titleKey: 'navigation.login_log',
      get title() {
        return i18n.global.t('navigation.login_log')
      },
    },
    component: LoginLog,
  },
  {
    path: '/internet/trade/login-log',
    name: 'internet-trade-login-log',
    meta: {
      titleKey: 'navigation.trade_login_log',
      get title() {
        return i18n.global.t('navigation.trade_login_log')
      },
    },
    component: TradeLoginLog,
  },
  {
    path: '/internet/risk/list',
    name: 'internet-risk-list',
    meta: {
      titleKey: 'navigation.risk_list',
      get title() {
        return i18n.global.t('navigation.risk_list')
      },
    },
    component: RiskList,
  },
]

export default routes
