import { i18n } from '@/global/register-i18n'
import { RouteRecordRaw } from 'vue-router'
import TakeNodes from '@/views/market-subscription/send-for/take-nodes/take-nodes.vue'

import ReportOrderRecord from '@/views/market-subscription/send-for/report-order-record/report-order-record.vue' //新增-点击报表订购记录

import PackageManageMent from '@/views/market-subscription/send-for/package-management/package-management.vue'

import ClickQuotationPackage from '@/views/market-subscription/send-for/click-quotation-package/click-quotation-package.vue' // 新增点击报价套餐

import CustomerList from '@/views/market-subscription/customer/list/list.vue'
import MarketUsageLog from '@/views/market-subscription/customer/market-usage-log.vue'

import LoginLog from '@/views/market-subscription/customer/login-log.vue'

import ClickLog from '@/views/market-subscription/customer/click-log.vue'

import DeductionFee from '@/views/market-subscription/numerical-statement/deduction-fee.vue'

import OrderList from '@/views/market-subscription/numerical-statement/order-list.vue'

import User from '@/views/market-subscription/systems-management/user.vue'

import Role from '@/views/market-subscription/systems-management/role.vue'

import HandleLog from '@/views/market-subscription/systems-management/handle-log.vue'

import fileLog from '@/views/market-subscription/send-for/file-import-log/file-import-log.vue'

import TakeSeparate from '@/views/market-subscription/send-for/take-separate/take-separate.vue'

import ClickRecord from '@/views/market-subscription/send-for/click-record/click-record.vue' // 新增点击记录

import SettingManageMent from '@/views/market-subscription/send-for/setting-management/setting-management.vue'

import FreeRulesManageMent from '@/views/market-subscription/send-for/free-rules-management/free-rules-management.vue'
import FeeSetting from '@/views/market-subscription/send-for/fee-setting/fee-setting.vue'
import UnifiedReport from '@/views/market-subscription/numerical-statement/unified-report.vue'

const routes: RouteRecordRaw[] = [
  /** 客户管理 */
  {
    path: '/market-subscription/customer/list',
    name: 'market-subscription-customer-list',
    meta: {
      titleKey: 'navigation.client_list',
      get title() {
        return i18n.global.t('navigation.client_list')
      },
    },
    component: CustomerList,
  },
  {
    path: '/market-subscription/customer/market-usage-log',
    name: 'market-subscription-customer-market-usage-log',
    meta: {
      titleKey: 'navigation.md_usage_log',
      get title() {
        return i18n.global.t('navigation.md_usage_log')
      },
    },
    component: MarketUsageLog,
  },
  {
    path: '/market-subscription/customer/login-log',
    name: 'market-subscription-customer-login-log',
    meta: {
      titleKey: 'navigation.client_login_log',
      get title() {
        return i18n.global.t('navigation.client_login_log')
      },
    },
    component: LoginLog,
  },
  {
    path: '/market-subscription/customer/click-log',
    name: 'market-subscription-customer-click-log',
    meta: {
      titleKey: 'navigation.client_click_log',
      get title() {
        return i18n.global.t('navigation.client_click_log')
      },
    },
    component: ClickLog,
  },
  /** 订购管理 */
  /*订单记录，更名为“串流行情订购记录*/
  {
    path: '/market-subscription/send-for/take-nodes',
    name: 'market-subscription-send-for-take-nodes',
    meta: {
      titleKey: 'navigation.order_records',
      get title() {
        return i18n.global.t('navigation.order_records')
      },
    },
    component: TakeNodes,
  },
  /**新增-点击报价订购记录**/
  {
    path: '/market-subscription/send-for/report-order-record',
    name: 'market-subscription-send-for-report-order-record',
    meta: {
      titleKey: 'navigation.click_quote_orders',
      get title() {
        return i18n.global.t('navigation.click_quote_orders')
      },
    },
    component: ReportOrderRecord,
  },
  {
    path: '/market-subscription/send-for/take-separate',
    name: 'market-subscription-send-for-take-separate',
    meta: {
      titleKey: 'navigation.package_assignments',
      get title() {
        return i18n.global.t('navigation.package_assignments')
      },
    },
    component: TakeSeparate,
  },
  /**新增-点击记录**/
  {
    path: '/market-subscription/send-for/click-record',
    name: 'market-subscription-send-for-click-record',
    meta: {
      titleKey: 'navigation.click_records',
      get title() {
        return i18n.global.t('navigation.click_records')
      },
    },
    component: ClickRecord,
  },
  /*套餐列表，更名为串流行情套餐*/
  {
    path: '/market-subscription/send-for/package-management',
    name: 'market-subscription-send-for-package-management',
    meta: {
      titleKey: 'navigation.package_list',
      get title() {
        return i18n.global.t('navigation.package_list')
      },
    },
    component: PackageManageMent,
  },
  /*新增-点击报价套餐*/
  {
    path: '/market-subscription/send-for/click-quotation-package',
    name: 'market-subscription-send-for-click-quotation-package',
    meta: {
      titleKey: 'navigation.click_packages',
      get title() {
        return i18n.global.t('navigation.click_packages')
      },
    },
    component: ClickQuotationPackage,
  },
  {
    path: '/market-subscription/send-for/setting-management',
    name: 'market-subscription-send-for-setting-management',
    meta: {
      titleKey: 'navigation.default_packages',
      get title() {
        return i18n.global.t('navigation.default_packages')
      },
    },
    component: SettingManageMent,
  },
  {
    path: '/market-subscription/send-for/free-rules-management',
    name: 'market-subscription-send-for-free-rules-management',
    meta: {
      titleKey: 'navigation.gift_rules',
      get title() {
        return i18n.global.t('navigation.gift_rules')
      },
    },
    component: FreeRulesManageMent,
  },
  {
    path: '/market-subscription/send-for/fee-setting',
    name: 'market-subscription-send-for-fee-setting',
    meta: {
      titleKey: 'navigation.fee_settings',
      get title() {
        return i18n.global.t('navigation.fee_settings')
      },
    },
    component: FeeSetting,
  },

  {
    path: '/market-subscription/send-for/file-import-log',
    name: 'file-import-log',
    meta: {
      titleKey: 'navigation.file_import_log',
      get title() {
        return i18n.global.t('navigation.file_import_log')
      },
    },
    component: fileLog,
  },
  /** 统计报表 */
  {
    path: '/market-subscription/numerical-statement/unified-report',
    name: 'unified-report',
    meta: {
      titleKey: 'navigation.unified_report',
      get title() {
        return i18n.global.t('navigation.unified_report')
      },
    },
    component: UnifiedReport,
  },
  /*新增：上报报表*/
  {
    path: '/market-subscription/numerical-statement/deduction-fee',
    name: 'numerical-statement-send-for-deduction-fee',
    meta: {
      titleKey: 'navigation.deduction_records',
      get title() {
        return i18n.global.t('navigation.deduction_records')
      },
    },
    component: DeductionFee,
  },
  {
    path: '/market-subscription/numerical-statement/order-list',
    name: 'numerical-statement-send-for-order-list',
    meta: {
      titleKey: 'navigation.package_report',
      get title() {
        return i18n.global.t('navigation.package_report')
      },
    },
    component: OrderList,
  },
  {
    path: '/market-subscription/numerical-statement/kyc-list',
    name: 'numerical-statement-kyc-list',
    meta: {
      titleKey: 'navigation.us_kyc',
      get title() {
        return i18n.global.t('navigation.us_kyc')
      },
    },
    component: () => import('@/views/market-subscription/numerical-statement/kyc-list.vue'),
  },
  {
    path: '/market-subscription/numerical-statement/file-import-log-us',
    name: 'numerical-statement-send-for-file-import-log-us',
    meta: {
      titleKey: 'navigation.us_kyc_import',
      get title() {
        return i18n.global.t('navigation.us_kyc_import')
      },
    },
    component: fileLog,
  },
  /** 系统管理 */
  {
    path: '/market-subscription/systems-management/user',
    name: 'market-subscription-systems-management-user',
    meta: {
      titleKey: 'navigation.user_management',
      get title() {
        return i18n.global.t('navigation.user_management')
      },
    },
    component: User,
  },

  {
    path: '/market-subscription/systems-management/role',
    name: 'market-subscription-systems-management-role',
    meta: {
      titleKey: 'navigation.role_management',
      get title() {
        return i18n.global.t('navigation.role_management')
      },
    },
    component: Role,
  },
  {
    path: '/market-subscription/systems-management/handle-log',
    name: 'market-subscription-systems-management-handle-log',
    meta: {
      titleKey: 'navigation.operation_log',
      get title() {
        return i18n.global.t('navigation.operation_log')
      },
    },
    component: HandleLog,
  },
  {
    path: '/market-subscription/systems-management/login-log',
    name: 'market-subscription-systems-management-login-log',
    meta: {
      titleKey: 'navigation.login_log',
      get title() {
        return i18n.global.t('navigation.login_log')
      },
    },
    component: () => import('@/views/market-subscription/systems-management/login-log.vue'),
  },
  {
    path: '/account-management-center/uc/user-management',
    name: 'user-management',
    meta: {
      titleKey: 'navigation.user_management',
      get title() {
        return i18n.global.t('navigation.user_management')
      },
    },
    component: () => import('@/views/market-subscription/uc/user-management/user-management.vue'),
  },
  {
    path: '/account-management-center/uc/role-management',
    name: 'role-management',
    meta: {
      titleKey: 'navigation.role_management',
      get title() {
        return i18n.global.t('navigation.role_management')
      },
    },
    component: () => import('@/views/market-subscription/uc/role-management/role-management.vue'),
  },
  {
    path: '/account-management-center/department-management',
    name: 'department-management',
    meta: {
      titleKey: 'navigation.department_management',
      get title() {
        return i18n.global.t('navigation.department_management')
      },
    },
    component: () =>
      import('@/views/market-subscription/uc/department-management/department-management.vue'),
  },
  {
    path: '/account-management-center/login-log',
    name: 'login-log',
    meta: {
      titleKey: 'navigation.login_log',
      get title() {
        return i18n.global.t('navigation.login_log')
      },
    },
    component: () => import('@/views/market-subscription/uc/login-log/login-log.vue'),
  },
  {
    path: '/account-management-center/file-import-log',
    name: 'file-import-log',
    meta: {
      titleKey: 'navigation.login_log',
      get title() {
        return i18n.global.t('navigation.login_log')
      },
    },
    component: () => import('@/views/market-subscription/uc/file-import-log/file-import-log.vue'),
  },
]

export default routes
