import { i18n } from '@/global/register-i18n'
import { RouteRecordRaw } from 'vue-router'

import DepartmentManagement from '@/views/account-management-center/system-management/department-management/department-management.vue'
import LoginLog from '@/views/account-management-center/system-management/login-log/login-log.vue'
import OperationLog from '@/views/account-management-center/system-management/operation-log/operation-log.vue'
import RoleManagement from '@/views/account-management-center/system-management/role-management/role-management.vue'
import UserManagement from '@/views/account-management-center/system-management/user-management/user-management.vue'
import FileImportLog from '@/views/account-management-center/system-management/file-import-log/file-import-log.vue'
import SensitiveWordFiltration from '@/views/account-management-center/system-management/sensitive-word-filtration/sensitive-word-filtration.vue'
import MenuConfig from '@/views/account-management-center/system-management/menu-config/menu-config.vue'
import ExchangerateMaganement from '@/views/account-management-center/system-management/exchange-rate-management/exchange-rate-management.vue'

const routes: Array<RouteRecordRaw> = [
  {
    path: '/account-management-center/department-management',
    name: 'account-management-center-department-management',
    meta: {
      titleKey: 'navigation.department_management',
      get title() {
        return i18n.global.t('navigation.department_management')
      },
    },
    component: DepartmentManagement,
  },
  {
    path: '/account-management-center/login-log',
    name: 'account-management-center-login-log',
    meta: {
      titleKey: 'navigation.login_log',
      get title() {
        return i18n.global.t('navigation.login_log')
      },
    },
    component: LoginLog,
  },
  {
    path: '/account-management-center/operation-log',
    name: 'account-management-center-operation-log',
    meta: {
      titleKey: 'navigation.operation_log',
      get title() {
        return i18n.global.t('navigation.operation_log')
      },
    },
    component: OperationLog,
  },
  {
    path: '/account-management-center/role-management',
    name: 'account-management-center-role-management',
    meta: {
      titleKey: 'navigation.role_management',
      get title() {
        return i18n.global.t('navigation.role_management')
      },
    },
    component: RoleManagement,
  },
  {
    path: '/account-management-center/user-management',
    name: 'account-management-center-user-management',
    meta: {
      titleKey: 'navigation.user_management',
      get title() {
        return i18n.global.t('navigation.user_management')
      },
    },
    component: UserManagement, // UserManagement
  },
  {
    path: '/account-management-center/file-import-log',
    name: 'account-management-center-file-import-log',
    meta: {
      titleKey: 'navigation.file_import_log',
      get title() {
        return i18n.global.t('navigation.file_import_log')
      },
    },
    component: FileImportLog,
  },
  {
    path: '/account-management-center/sensitive-word-filtering',
    name: 'sensitive-word-filtration',
    meta: {
      titleKey: 'navigation.sensitive_word_filter',
      get title() {
        return i18n.global.t('navigation.sensitive_word_filter')
      },
    },
    component: SensitiveWordFiltration,
  },
  {
    path: '/account-management-center/menu-config',
    name: 'account-management-center-menu-config',
    meta: {
      titleKey: 'navigation.menu_config',
      get title() {
        return i18n.global.t('navigation.menu_config')
      },
    },
    component: MenuConfig,
  },
  {
    path: '/account-management-center/rate-setting',
    name: 'account-management-center-rate-setting',
    meta: {
      titleKey: 'navigation.fx_settings',
      get title() {
        return i18n.global.t('navigation.fx_settings')
      },
    },
    component: ExchangerateMaganement,
  },
  /* 账户管理中心-end */
]
export default routes
