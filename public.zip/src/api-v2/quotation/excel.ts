import { i18n } from '@/global/register-i18n'
import { exportFile } from '@/utils'
import { authorizedCommonJavaInst } from '../common-java-instance'
import { baseUrl } from '.'

// 导入-列表
const t = i18n.global.t

export const importList = (data: object) => {
  return authorizedCommonJavaInst.post(`${baseUrl}/excel/importLog/list`, data)
}

// 导出模板
export const importLogDownload = (
  data: Record<string, any> = {},
  filename = t('import_template') + '.xls'
) => {
  return exportFile(baseUrl, '/excel/importLog/downloadLog', data, filename)
}
