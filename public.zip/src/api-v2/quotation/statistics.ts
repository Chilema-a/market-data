import { i18n } from '@/global/register-i18n'
import request from '@/utils/request/request'
import { exportFile } from '@/utils'
import { authorizedCommonJavaInst } from '../common-java-instance'
import { baseUrl } from '.'

/**
 * 导出点击报价统计
 */
const t = i18n.global.t

export const exportClickProduct = (
  data: Record<string, any>,
  filename = t('click_quote_statistics') + '.xls'
) => {
  return exportFile(baseUrl, '/statistics/export/click/product', data, filename)
}

/**
 * 点击报价统计
 */
export const clickProduct = (data: object, loading?: boolean) => {
  return request(`${baseUrl}/statistics/click/product`, 'post', data, loading)
}

/**
 * 串流行情套餐统计
 */
export const quo = (data: object, loading?: boolean) => {
  return request(`${baseUrl}/statistics/quo`, 'post', data, loading)
}

/**
 * 串流行情产品统计
 */
export const quoProduct = (data: object, loading?: boolean) => {
  return request(`${baseUrl}/statistics/quo/product`, 'post', data, loading)
}

/**
 * 套餐订购报表
 */
export const packageBuyList = (data: object) => {
  return authorizedCommonJavaInst.post(`${baseUrl}/report/package/buy/list`, data)
}

// 导出串流行情产品统计
export const productExport = (
  data: Record<string, any>,
  filename = t('md_product_stats') + '.xls'
) => {
  return exportFile(baseUrl, '/statistics/export/quo/product', data, filename)
}

// 导出串流行情产品统计
export const sendExport = (
  data: Record<string, any>,
  filename = t('md_package_stats') + '.xls'
) => {
  return exportFile(baseUrl, '/statistics/export/quo', data, filename)
}

/**
 * 套餐订购报表导出
 */
export const packageExport = (data: object, loading?: boolean) => {
  return request(`${baseUrl}/statistics/export/package`, 'post', data, loading)
}

/**
 * 扣费记录
 */
export const payList = (data: object) => {
  // return request(`${baseUrl}/report/pay/list`, 'post', data, loading)
  return authorizedCommonJavaInst.post(`${baseUrl}/report/pay/list`, data)
}

/**
 * 扣费记录导出
 */
export const payExport = (data: object, loading?: boolean) => {
  return request(`${baseUrl}/statistics/export/package`, 'post', data, loading)
}

// 套餐订购报表导出 order-list
export const orderListExport = (
  data: Record<string, any>,
  filename = t('package_orders') + '.xls'
) => {
  return exportFile(baseUrl, '/report/export/package/buy/list', data, filename)
}

// 订购管理-点击报价订购记录-审核
export const orderReview = (data: object) => {
  return request(`${baseUrl}/order/review`, 'post', data)
}

// 上报报表-订购明细表-导出
export const statisticsExportOrder = (
  data: Record<string, any>,
  filename = t('md_product_stats') + '.xls'
) => {
  return exportFile(baseUrl, '/statistics/export/order/detail', data, filename)
}
// 上报报表-试用表-导出
export const statisticsExportTrial = (
  data: Record<string, any>,
  filename = t('md_product_stats') + '.xls'
) => {
  return exportFile(baseUrl, '/statistics/export/trial/list', data, filename)
}

// 上报报表-NYSE美股行情用户声明表-导出
export const userDeclarationExportOrder = (
  data: Record<string, any>,
  filename = t('us_user_declaration_form') + '.xls'
) => {
  return exportFile(baseUrl, '/statistics/export/us/pi/list', data, filename)
}

// 上报报表-NYSE美股行情上报表-导出
export const marketReportExportOrder = (
  data: Record<string, any>,
  filename = t('us_market_report') + '.xls'
) => {
  return exportFile(baseUrl, '/statistics/export/us/order/detail', data, filename)
}

// 订购管理-字典类型-审核类型
export const getByTypes = (data: object) => {
  return request(`${baseUrl}/sys/dict/getByTypes`, 'post', data)
}

// 订购管理-字典类型-审核类型
export const getProgress = (data: object) => {
  return request(`${baseUrl}/statistics/get/import/progress`, 'post', data)
}
