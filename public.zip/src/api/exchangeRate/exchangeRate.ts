import { i18n } from '@/global/register-i18n'
import request, { noEditrequest } from '@/utils/request/request'
import { BASE_URL } from '@/utils/request/config'
import { exportFile } from '@/utils'

// 汇率-查询
const t = i18n.global.t

export const getRateList = (data?: object, loading?: boolean) => {
  return request('/trading/sysExchangeRate/rateList', 'post', data, loading)
}

// 汇率-保存
export const saveRate = (data?: object, loading?: boolean) => {
  return noEditrequest('/trading/sysExchangeRate/saveRate', 'post', data, loading)
}

// 汇率修改日誌查詢
export const rateLogList = (data?: object, loading?: boolean) => {
  return request('/trading/sysExchangeRate/rateLogList', 'post', data, loading)
}

// 汇率修改日志-导出
export const logExport = (
  data: Record<string, any> = {},
  filename = t('exchange_rate_logs') + '.xlsx'
) => {
  return exportFile(BASE_URL, 'trading/sysExchangeRate/logExport', data, filename)
}
