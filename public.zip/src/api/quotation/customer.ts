import { i18n } from '@/global/register-i18n'
import request from '@/utils/request/request'
import { exportFile } from '@/utils'
import { baseUrlUc, baseUrl } from '.'

// 客户列表
const t = i18n.global.t

export const customerList = (data: object) => {
  return request(`${baseUrl}/cus/list`, 'post', data)
}

// 客户登录日志
export const loginLogList = (data: object) => {
  return request(`/uc/customer/loginLog/list`, 'post', data)
}

// 客户登录日志导出
export const loginLogExport = (data: Record<string, any>) => {
  return exportFile(baseUrlUc, '/cus/loginLog/list', data, t('customer_login_logs') + '.xls')
}

// 客户登录列表导出
export const loginListExport = (data: Record<string, any>) => {
  return exportFile(
    baseUrlUc,
    'uc/customer/loginLog/export',
    data,
    t('customer_login_list') + '.xls'
  )
}

/** 导出用户列表 */
export const exportCusList = (data: Record<string, any>) => {
  return exportFile(baseUrl, '/cus/export/list', data, t('customer_list_export') + '.xls')
}

/** 导出用户列表 */
export const exportCus = (data: Record<string, any>) => {
  return exportFile(baseUrl, '/cus/export/list', data, t('customer_list_export') + '.xls')
}
