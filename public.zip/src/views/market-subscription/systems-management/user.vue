<template>
  <div class="page-container">
    {{ $t('user') }}
    <el-button v-permission="'sys:home:add'">123</el-button>
    <el-icon><i-alarm-clock /></el-icon>
  </div>
</template>
