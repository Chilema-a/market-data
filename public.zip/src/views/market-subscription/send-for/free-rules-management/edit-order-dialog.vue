<template>
  <el-dialog
    v-model="dialogTableVisible"
    :close-on-click-modal="false"
    :title="titleText"
    width="800px"
    center
    @close="dialogClean"
  >
    <el-form
      ref="formRef"
      :model="form"
      :rules="formRules"
      label-width="auto"
      :disabled="formDisabled"
    >
      <el-input v-model="form.id" type="hidden" />
      <!-- <check-lang v-model="lang" /> -->
      <el-form-item :label="`${$t('rule_name')}：`" prop="name">
        <el-input v-model="form.name" />
      </el-form-item>
      <el-form-item :label="`${$t('gift_package')}：`" prop="packageId">
        <el-select
          v-model="form.packageId"
          :placeholder="$t('please_select')"
          :disabled="isLocalFormDisable"
        >
          <el-option
            v-for="item in quoPackages"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item :label="`${$t('package_cycle')}：`" prop="cycle">
        <span>{{ cycleText }}</span>
      </el-form-item>
      <el-form-item :label="`${$t('user_region')}：`" prop="regionSelect">
        <el-radio-group v-model="form.regionSelect" :disabled="isLocalFormDisable">
          <el-row>
            <el-col :span="12"
              ><el-radio :label="1">{{ $t('region_mainland') }}</el-radio></el-col
            >
            <!-- <el-col :span="12"
              ><el-radio :label="2">{{ $t('region_HongKong') }}</el-radio></el-col
            >
            <el-col :span="12"
              ><el-radio :label="3">{{ $t('region_global') }}</el-radio></el-col
            > -->
            <el-col :span="12"
              ><el-radio :label="4">{{ $t('region_other') }}</el-radio></el-col
            >
          </el-row>
        </el-radio-group>
      </el-form-item>
      <el-form-item :label="`${$t('gift_trigger')}：`" prop="condition">
        <el-radio-group v-model="form.condition" :disabled="isLocalFormDisable">
          <el-row>
            <el-col :span="24"
              ><el-radio label="uc_register">{{
                $t('register_platform_account')
              }}</el-radio></el-col
            >
            <el-col :span="24"
              ><el-radio label="bind_trade">{{
                $t('binding_transaction_account')
              }}</el-radio></el-col
            >
            <el-col :span="24">
              <el-radio label="login_trade"
                >{{ $t('login_trading_account') }}
                <span class="remark-label">{{ $t('gift_repeat_note') }}</span></el-radio
              >
            </el-col>
          </el-row>
        </el-radio-group>
      </el-form-item>
      <el-form-item :label="`${$t('gift_duration')}：`" prop="number">
        <el-radio-group v-model="num" @change="changeSelect">
          <el-radio :label="0">{{ $t('unlimited') }}</el-radio>
          <el-radio :label="1">{{ $t('custom') }}</el-radio>
        </el-radio-group>
        <el-input v-if="num != 0" v-model.number="form.number" class="input-num" />
        <div class="input-tip">
          <span class="remark-label">{{ $t('gift_duration_tip') }}</span>
        </div>
      </el-form-item>
      <el-form-item :label="`${$t('gift_term')}：`" prop="triggerLimit">
        <el-radio-group v-model="triggerLimit" @change="changeSelect1">
          <el-radio :label="0">{{ $t('unlimited') }}</el-radio>
          <el-radio :label="1">{{ $t('custom') }}</el-radio>
        </el-radio-group>
        <el-tooltip
          class="box-item"
          effect="dark"
          :content="$t('gift_term_tooltip')"
          placement="top-start"
        >
          <el-input v-if="triggerLimit != 0" v-model.number="form.triggerLimit" class="input-num" />
        </el-tooltip>

        <div class="input-tip">
          <span class="remark-label">{{ $t('gift_term_tip') }}</span>
        </div>
      </el-form-item>
      <el-form-item :label="`${$t('state')}：`" prop="enable">
        <el-radio-group v-model="form.enable" :disabled="isLocalFormDisable">
          <el-radio :label="true">{{ $t('enabled') }}</el-radio>
          <el-radio :label="false">{{ $t('disable') }}</el-radio>
        </el-radio-group>
      </el-form-item>
    </el-form>
    <template #footer>
      <div v-if="!formDisabled">
        <el-button type="primary" :loading="loading" @click="editConfirm">{{
          $t('determine')
        }}</el-button>
        <el-button @click="dialogClean">{{ $t('cancel') }}</el-button>
      </div>
    </template>
  </el-dialog>
</template>
<script lang="ts">
import { reactive, ref, toRefs, computed, onBeforeMount, defineComponent, watch } from 'vue'
import { useI18n } from 'vue-i18n'
import { Plus } from '@element-plus/icons-vue'
import CheckLang, { getLangIcon } from '@/components/check-lang/check-lang'
import { selectQuoList } from '@/api/quotation/settingQuo'
import { saveList, updateList } from '@/api/quotation/freeQuo'
import { quoList } from '@/api/quotation'

enum DialogType {
  Add = 'Add', // 添加
  Edit = 'Edit', // 编辑
}

export default defineComponent({
  name: 'EditOrderDialog',
  components: {
    CheckLang,
    Plus,
  },
  props: {
    sure: Function,
    cancel: {
      type: Function,
      default: () => {},
    },
  },
  emits: ['getData'],
  setup(_: Record<string, any>, { emit }: Record<string, any>) {
    const { t } = useI18n()
    const dialogTableVisible = ref(false)
    const num = ref(1)
    const triggerLimit = ref(1)
    const state = reactive({
      type: DialogType.Add,
      formDisabled: false,
      isLocalFormDisable: false,
    })
    const formRef = ref()
    const quoPackages = ref([])
    const form: Record<string, any> = reactive({
      id: '',
      type: 1,
      condition: '',
      enable: true,
      number: '',
      packageId: '',
      regionSelect: '',
      triggerLimit: '',
      name: '',
      cycle: '',
    })
    const cycleText = computed(() => {
      const cycleMap: Record<number, string> = {
        1: t('day'),
        2: t('month'),
        3: t('week'),
      }
      return cycleMap[form.cycle]
    })
    const lang = ref('zh-CN')
    const langIndex = computed(() => {
      const index = form.i18ns.findIndex((item: Record<string, any>) => item.lang === lang.value)
      return index
    })
    const checkLangImage = computed(() => getLangIcon(lang.value))
    const checkTriggerLimit = (rule: any, value: any, callback: any) => {
      console.log('val++++triggerLimit', value, triggerLimit.value)
      if (triggerLimit.value === 0) {
        callback()
        return
      }
      if (!Number.isInteger(value)) {
        callback(new Error(t('enter_integer')))
      } else {
        if (value < form.number) {
          callback(new Error(t('gift_term_validation')))
        } else {
          callback()
        }
      }
    }
    const formRules = {
      condition: {
        required: true,
        trigger: 'change',
        get message() {
          return t('required_field')
        },
      },
      number: [
        {
          required: true,
          get message() {
            return t('required_field')
          },
        },
        {
          type: 'number',
          get message() {
            return t('numbers_only')
          },
        },
      ],
      packageId: {
        required: true,
        trigger: 'change',
        get message() {
          return t('required_field')
        },
      },
      regionSelect: {
        required: true,
        trigger: 'change',
        get message() {
          return t('required_field')
        },
      },
      triggerLimit: [
        {
          required: true,
          get message() {
            return t('required_field')
          },
        },
        { validator: checkTriggerLimit, trigger: 'blur' },
      ],
      name: {
        required: true,
        trigger: 'change',
        get message() {
          return t('required_field')
        },
      },
    }
    function changeSelect(val: any) {
      if (val == 0) {
        formRef.value.clearValidate()
        // formRef.value.resetFields()
        form.number = 0
        form.triggerLimit = 0
        triggerLimit.value = 0
      } else {
        form.number = ''
      }
    }
    function changeSelect1(val: any) {
      if (val == 0) {
        formRef.value.clearValidate()
        // formRef.value.resetFields()
        form.triggerLimit = 0
      } else {
        form.triggerLimit = ''
      }
    }
    function open(v?: Record<string, any>, operateStatus?: number | boolean) {
      state.formDisabled = false
      state.isLocalFormDisable = false

      if (v) {
        if (operateStatus === 2) {
          state.type = DialogType.Edit
          form.id = v.id
          form.condition = v.condition
          form.conditionName = v.conditionName
          form.cycle = v.cycle
          form.enable = v.enable
          form.name = v.name
          form.number = v.number
          form.packageId = v.packageId
          form.packageName = v.packageName
          form.region = v.region
          form.regionSelect = v.regionSelect
          form.regionSelectStr = v.regionSelectStr
          form.regionType = v.regionType
          form.triggerLimit = v.triggerLimit
          num.value = v.number > 0 ? 1 : 0
          triggerLimit.value = v.triggerLimit > 0 ? 1 : 0
        } else {
          state.type = DialogType.Add
        }
      }
      dialogTableVisible.value = true
    }
    const titleText = computed(() => {
      const obj = {
        [DialogType.Add]: t('add_gift_rule'),
        [DialogType.Edit]: t('edit_gift_rule'),
      }
      return obj[state.type]
    })

    // 弹窗取消
    function dialogClean() {
      formRef.value.resetFields()
      Object.keys(form).forEach((key) => {
        if (key === 'enable') {
          form[key] = true
        } else {
          form[key] = ''
        }
      })
      num.value = 1
      triggerLimit.value = 1

      dialogTableVisible.value = false
    }

    // 弹窗确认
    function editConfirm() {
      formRef.value.validate((validate: boolean) => {
        if (!validate) {
          return
        }
        dialogSure()
      })
    }
    const loading = ref(false)

    // 请求接口
    function dialogSure() {
      form.type = 1
      if (state.type === DialogType.Add) {
        loading.value = true
        const keys = Object.keys(form)
        const prm: any = {}
        keys.forEach((key) => {
          if (key !== 'id') {
            prm[key] = form[key]
          }
        })
        saveList(prm)
          .then(() => {
            dialogClean()
            emit('getData')
          })
          .catch((err) => {
            console.log(err)
          })
          .finally(() => {
            loading.value = false
          })
      } else if (state.type === DialogType.Edit) {
        loading.value = true
        updateList({
          ...form,
        })
          .then(() => {
            dialogClean()
            emit('getData')
          })
          .catch((err) => {
            console.log(err)
          })
          .finally(() => {
            loading.value = false
          })
      }
    }
    const products: Record<string, any> = ref([])
    /**
     * 获取行情套餐
     */
    function selectPackage() {
      //获取选择套餐
      selectQuoList({
        enable: true,
        status: '10',
        defaultAuthorize: 'false',
        pageSize: 10000,
      }).then((res) => {
        quoPackages.value = res.result.records.map((v: any) => ({
          label: v.name,
          value: v.id,
          count: v.count,
        }))
      })
    }
    watch(
      () => form.packageId,
      (packageId: string) => {
        // console.log(packageId, '监听')
        if (packageId) {
          let newItem = quoPackages.value.filter((item: any) => item.value == packageId)[0]
          form.cycle = newItem.count
        }
      }
    )
    onBeforeMount(() => {
      selectPackage()
    })
    return {
      lang,
      checkLangImage,
      langIndex,
      dialogTableVisible,
      open,
      close,
      editConfirm,
      dialogClean,
      titleText,
      DialogType,
      ...toRefs(state),
      form,
      formRules,
      formRef,
      loading,
      Plus,
      quoPackages,
      num,
      triggerLimit,
      changeSelect,
      changeSelect1,
      cycleText,
    }
  },
})
</script>

<style lang="scss" scoped>
/* stylelint-disable selector-class-pattern, selector-pseudo-class-no-unknown -- Element Plus and Vue scoped selectors. */
.edit-streaming-quote-box {
  display: flex;

  .edit-streaming-quote-box-item {
    display: flex;
    flex-direction: column;
    width: 50%;
  }

  .item-box-right {
    padding: 70px 0 0;
  }

  :deep(.el-form-item--default) {
    margin: 20px 0;
    font-weight: 600;
  }

  :deep(.el-checkbox-group) {
    display: flex;
  }

  :deep(.el-textarea) {
    width: 230px;
  }

  img {
    width: 20px;
    height: 20px;
  }
}

.avatar-uploader {
  :deep(.el-upload-dragger),
  .avatar {
    width: 150px;
    height: 150px;
  }
  .el-icon.avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    text-align: center;
    position: relative;
    bottom: 15px;
    right: 15px;
  }
}

.bg {
  background: #f2f2f5;
}

.lang-image-box {
  :deep(.el-form-item__label) {
    position: relative;
    display: flex;
  }

  :deep(.el-form-item__label) > div {
    display: inline-flex;
    align-items: center;
    gap: 6px;
  }

  .lang-image {
    display: inline-flex;
    flex-shrink: 0;
  }
}

.valid-pic {
  flex-basis: 100%;
  margin-top: 4px;
  line-height: 18px;
  overflow-wrap: anywhere;
  font-size: 12px;
  color: #ff0000;
}

.input-num {
  margin-left: 10px;
  flex: 0 1 120px;
}

.remark-label {
  font-size: 10px;
  color: gray;
}

.input-tip {
  width: 100%;
  margin-top: 4px;
  line-height: 18px;
  overflow-wrap: anywhere;
}
</style>
