<template>
  <!-- 订购管理-串流行情订购记录 -->
  <div class="page-container">
    <el-tabs v-model="activeName" class="order-record-tabs" @tab-click="handleClick">
      <el-tab-pane :label="$t('allNotes')" name="first"></el-tab-pane>
      <el-tab-pane :label="$t('buyNotes')" name="second"></el-tab-pane>
      <el-tab-pane :label="$t('freeNotes')" name="third"></el-tab-pane>
    </el-tabs>
    <!-- :config="activeName !== 'first' ? newFilterConfig : filterConfig" -->
    <base-filter
      :loading="isLoading"
      :config="filterConfig"
      :tab-active="activeName"
      @on-search="searchHandle"
      @on-reset="resetHandle"
    ></base-filter>
    <div class="tool operate-buttons">
      <el-button
        v-permission="'quo:order:buy'"
        class="toolbar-add-button"
        type="primary"
        @click="openAddOrder"
      >
        {{ $t('new_order_streaming_quote') }}
      </el-button>
      <el-button v-permission="'quo:order:import'" plain type="primary" @click="openImportDialog">
        {{ $t('bulk_import') }}
      </el-button>
      <el-button
        v-permission="'quo:order:export'"
        plain
        type="info"
        :loading="isExportLoading"
        class="export-button"
        @click="exportFunc"
      >
        {{ $t('export') }}
      </el-button>
      <!-- <el-button
        v-permission="'order:batch:review'"
        type="info"
        :loading="isExportLoading"
        @click="reviewBatch"
        >
        {{ $t('batch_review') }}
        </el-button
      > -->
    </div>

    <base-table :config="tableConfig" :pagination="pagination" :is-table-loading="isLoading">
      <template #oldOrderId>
        <el-table-column align="center" :label="$t('original_order_number')" width="160px">
          <template #default="scope">
            <originalOrderPopover
              v-if="scope.row.oldOrderId"
              :key="scope.row.oldOrderId"
              :order-id="scope.row.oldOrderId"
            />
            <span v-else>--</span>
          </template>
        </el-table-column>
      </template>

      <template #period>
        <el-table-column align="center" :label="$t('package_cycle')" width="100px">
          <template #default="scope">
            <div>
              {{ scope.row.period }}
              <!-- <span v-if="scope.row.period == 1">{{ $t('day') }}</span>
              <span v-if="scope.row.period == 2">{{ $t('natural_month') }}</span>
              <span v-if="scope.row.period == 3">{{ $t('week') }}</span> -->
            </div>
          </template>
        </el-table-column>
      </template>

      <!-- <template #amount>
        <el-table-column
          align="center"
          :label="$t('amount_paid')"
          width="100px"
          prop="amount"
          sortable="custom"
        >
          <template #default="scope">
            <div>
              <span>{{ scope.row.amount }} {{ scope.row.currency }}</span>
              {{ scope.row.amount }}
            </div>
          </template>
        </el-table-column>
      </template> -->

      <template #status>
        <el-table-column align="center" :label="$t('audit_status')" width="100px">
          <template #default="scope">
            <div>
              <span v-if="scope.row.status == -10">{{ $t('audit_reject') }}</span>
              <span v-if="scope.row.status == 0">{{ $t('check_pending') }}</span>
              <span v-if="scope.row.status == 10">{{ $t('audit_approve') }}</span>
            </div>
          </template>
        </el-table-column>
      </template>

      <template #marketType>
        <el-table-column align="center" :label="$t('quote_market')" width="100px">
          <template #default="scope">
            <div>
              {{ scope.row.productName }}
            </div>
          </template>
        </el-table-column>
      </template>

      <template #enableStart>
        <el-table-column
          align="center"
          :label="$t('expect_take_effect')"
          prop="enableStart"
          width="120px"
          sortable="custom"
        >
          <template #default="scope">
            <div>
              {{ calcEnableStart(scope.row) }}
            </div>
          </template>
        </el-table-column>
      </template>

      <!-- <template #orderEnableStatus>
        <el-table-column align="center" :label="$t('status')" width="100px">
          <template #default="scope">
            <div>
              {{ formatOrderStatus(scope.row) }}
            </div>
          </template>
        </el-table-column>
      </template> -->

      <template #isGive>
        <el-table-column align="center" :label="$t('is_presented')" width="100px">
          <template #default="scope">
            <div>
              {{ scope.row.isGive == true ? $t('yes') : scope.row.isGive == false ? $t('no') : '' }}
            </div>
          </template>
        </el-table-column>
      </template>

      <template #handler>
        <el-table-column align="center" :label="$t('operate')" width="260px" fixed="right">
          <template #default="scope">
            <div class="detailBtn">
              <el-button
                v-permission="'quo:order:modify'"
                :disabled="!canModifyOrder(scope.row)"
                type="text"
                class="text-primary"
                @click="modifyOrder(scope.row)"
              >
                {{ $t('modify') }}
              </el-button>
              <el-button
                v-permission="'quo:order:exchange'"
                :disabled="!canExchange(scope.row)"
                type="text"
                class="text-primary"
                @click="exchangeDialogRef.open(scope.row)"
              >
                {{ $t('exchange_order') }}
              </el-button>
              <el-button
                v-permission="'quo:order:review'"
                type="text"
                class="text-primary audit-button"
                :disabled="!canReviewOrder(scope.row)"
                @click="auditOrder(scope.row)"
              >
                {{ $t('audit') }}
              </el-button>
              <el-button
                v-permission="'quo:order:cancel'"
                :disabled="scope.row.canImmediateCancel !== true"
                type="text"
                class="text-primary"
                @click="cancelDialogRef.open(scope.row, 'apply')"
              >
                {{ $t('cancel') }}
              </el-button>
              <el-button
                v-permission="'quo:order:detail'"
                type="text"
                class="text-primary"
                @click="toInfo(scope.row)"
              >
                {{ $t('details') }}
              </el-button>
            </div>
          </template>
        </el-table-column>
      </template>
    </base-table>

    <quotationDialog ref="quotationRef" :init-form-values="initFormValues" @callback="getData" />
    <importDialog ref="importDialogRef" @callback="getData" />
    <exchangeDialog ref="exchangeDialogRef" @callback="getData" />
    <cancelDialog ref="cancelDialogRef" @callback="getData" />
    <!-- <examine-and-veriFy ref="examineAndVeriFyRef" @callback="getData" /> -->
    <reviewBatchDialog ref="reviewDialogRef" :selected-data="reviewSelection" @callback="getData" />
    <!-- <info-dialog ref="infoRef" /> -->
  </div>
</template>

<script setup lang="ts">
import { reactive, onBeforeMount, ref, Ref } from 'vue'
import { useI18n } from 'vue-i18n'
import dayjs from 'dayjs'

import { formToParams } from '@/utils'
import importDialog from './import-dialog.vue'
import quotationDialog from './quotation-dialog.vue'
import reviewBatchDialog from './review-batch-dialog.vue'
import exchangeDialog from './exchange-dialog.vue'
import cancelDialog from './cancel-dialog.vue'
import originalOrderPopover from './original-order-popover.vue'
import { canExchangeOrder } from './exchange'
import baseTable from '@/components/base-table/base-table'
import baseFilter from '@/components/base-filter/base-filter'
import { orderListReq, orderListExpor, requestMaintainTime } from '@/api-v2/quotation/order'
import { OperationType } from '@/utils/const'
import { AuditStatus } from '@/types/quotationType'
import {
  fetchDicts,
  fetchPackageOptions,
  fetchProductList,
  fetchQuotationOrderDetail,
} from '@/api-v2/quotation/query'
import { SelectOptions } from '@/types'
import { extractDict } from '@/utils/options-dictionary'
import { IInitFormValues } from './quotation-dialog-content.vue'

// #region options

const initFormValues = ref<IInitFormValues>()

const subTypeOptions = ref<SelectOptions>([])
const quoPackagesOptions = ref<SelectOptions>([])
const reviewStatusOptions = ref<SelectOptions>([])
const orderEnableStatusOptions = ref<SelectOptions>([])
const marketTypeOptions = ref<SelectOptions<number>>([])

function initDicts() {
  const dictPairs: [string, Ref<SelectOptions>][] = [
    ['sub_type', subTypeOptions],
    ['review_status', reviewStatusOptions],
    ['order_enable_staus', orderEnableStatusOptions],
  ]

  const keys = dictPairs.map((item) => item[0])

  fetchDicts(keys).then((res) => {
    dictPairs.forEach((item) => {
      extractDict(res?.result?.[item[0]], item[1])
    })
  })

  fetchPackageOptions(1).then((res: any) => {
    quoPackagesOptions.value = res.result.map((v: any) => ({
      label: v.name || v.packageName,
      value: v.id || v.packageId,
    }))
  })

  fetchProductList().then((res: any) => {
    marketTypeOptions.value = res.result.map((v: any) => ({
      label: v.name,
      value: v.productId,
    }))
  })
}
// #endregion

interface IMaintainTimeResult {
  startHour?: number | string
}

const startHour = ref<number | null>(null)

function parseHour(val: unknown): number | null {
  if (val === undefined || val === null || val === '') return null
  if (typeof val === 'number') return val
  const str = String(val).trim()
  if (str.includes(':')) {
    const [h, m = '0'] = str.split(':')
    const hourNum = Number(h)
    const minNum = Number(m)
    if (!isNaN(hourNum)) {
      return hourNum + (isNaN(minNum) ? 0 : minNum / 60)
    }
  }
  const num = Number(str)
  return isNaN(num) ? null : num
}

function fetchMaintainTime() {
  requestMaintainTime()
    .then((res: { result?: IMaintainTimeResult | number | string }) => {
      const result = res?.result
      const rawHour =
        typeof result === 'object' && result !== null && 'startHour' in result
          ? result.startHour
          : result
      startHour.value = parseHour(rawHour)
    })
    .catch((error: unknown) => {
      console.error('获取维护时间失败', error)
    })
}

function calcEnableStart(row: Record<string, unknown>): string {
  const fallback = typeof row?.enableStart === 'string' ? row.enableStart : '--'
  if (!row?.createTime || typeof row.createTime !== 'string' || startHour.value === null) {
    return fallback
  }
  const time = dayjs(row.createTime)
  if (!time.isValid()) {
    return fallback
  }

  const x = time.hour() + time.minute() / 60 + time.second() / 3600
  if (x < startHour.value) {
    return time.format('YYYY-MM-DD')
  }
  return time.add(1, 'day').format('YYYY-MM-DD')
}

onBeforeMount(() => {
  initDicts()
  fetchMaintainTime()
})
// const infoRef = ref()
const quotationRef = ref()
const importDialogRef = ref()
const exchangeDialogRef = ref()
const cancelDialogRef = ref()
const isLoading = ref<boolean>(false)

const ordering = ref({
  asc: true,
  column: '',
})
const { t } = useI18n()
const activeName = ref('first')
const tabNames: any = {
  first: undefined,
  second: false,
  third: true,
}

function openAddOrder() {
  initFormValues.value = undefined
  quotationRef.value.open(OperationType.Add)
}

function openImportDialog() {
  importDialogRef.value.open()
}

function fetchDetail(orderId: string) {
  return Promise.all([fetchQuotationOrderDetail(orderId), fetchPackageOptions()]).then(
    ([detailRes, packageOptionsRes]) => {
      return {
        detail: detailRes.result,
        packages: packageOptionsRes.result,
      }
    }
  )
}

function openDetail(row: Record<string, any>, operationType: OperationType) {
  const orderId = row.orderId
  fetchDetail(orderId).then((info) => {
    const { detail, packages } = info
    const prefillForm: IInitFormValues['form'] = {
      amount: detail.amount,
      customerId: detail.customerId,
      isGive: detail.isGive,
      packageId: detail.packageId?.toString(),
      tradeAccount: detail.tradeAccount,
      deductTimeType: detail.chargeType ?? detail.deductTimeType,
    }

    const staticFields: IInitFormValues['staticFields'] = {
      cusNo: detail.cusNo,
      mobile: detail.mobile,
      tbcAmount: detail.tbcAmount,
      orderId: orderId,
      isExchange:
        row.reviewType === 'EXCHANGE' || (row.reviewType == null && detail.isExchange === true),
      reviewRemark: row.reviewRemark || detail.reviewRemark,
      modifyRecord: detail.modifyRecord,
    }

    initFormValues.value = {
      form: prefillForm,
      staticFields,
      packages,
    }

    quotationRef.value.open(operationType)
  })
}

function toInfo(v: Record<string, any>) {
  openDetail(v, OperationType.Detail)
}

function auditOrder(v: Record<string, any>) {
  if (!canReviewOrder(v)) return
  if (v.reviewType === 'CANCEL') cancelDialogRef.value.open(v, 'review')
  else openDetail(v, OperationType.Audit)
}

function canModifyOrder(row: Record<string, any>) {
  if (row.canModify != null)
    return row.canModify === true && ['ORDER', 'CANCEL'].includes(row.modifyType)
  return row.status === AuditStatus.ReviewIng || row.status === AuditStatus.Reject
}

function canReviewOrder(row: Record<string, any>) {
  if (row.canReview != null)
    return row.canReview === true && ['ORDER', 'EXCHANGE', 'CANCEL'].includes(row.reviewType)
  return row.status === AuditStatus.ReviewIng && !!row.isReview
}

function canExchange(row: Record<string, any>) {
  if (row.canExchange != null) return row.canExchange === true
  if (row.modifyType === 'CANCEL' || row.reviewType === 'CANCEL') return false
  return canExchangeOrder(row)
}

function modifyOrder(row: Record<string, any>) {
  if (!canModifyOrder(row)) return
  if (row.modifyType === 'CANCEL') cancelDialogRef.value.open(row, 'modify')
  else openDetail(row, OperationType.Modify)
}
//父组件调用子组件的方法
const handleClick = (tab: any) => {
  activeName.value = tab.props.name
  // getData()
}

const tableConfig = reactive({
  tableProps: {
    data: [],
    height: '480',
  },
  tableEvent: {
    onSortChange: (column: Record<string, any>) => {
      ordering.value.column = ''
      pagination.paginationProps.currentPage = 1

      const { order, prop } = column
      if (order && prop) {
        const propArr: string[] = prop.split('.')
        const attribute = propArr.length === 1 ? propArr[0] : propArr[1]

        ordering.value = {
          asc: order === 'ascending',
          column: attribute,
        }
      }
      return getData()
    },
    onSelectionChange: (val: any) => {
      reviewSelection.value = val
    },
  },
  customColumns: [
    {
      get label() {
        return t('order_number')
      },
      prop: 'orderId',
      width: '160',
    },
    {
      get label() {
        return t('transaction_account')
      },
      prop: 'tradeAccount',
      width: '120',
      sortable: 'custom',
    },
    {
      get label() {
        return t('name')
      },
      prop: 'userName',
    },
    // { label: t('nickname'), prop: 'nickName', width: '120' },
    {
      get label() {
        return t('package')
      },
      prop: 'packageName',
      width: '140',
    },
    { slot: 'marketType' },
    { slot: 'period' },
    // { slot: 'amount' },
    {
      get label() {
        return t('amount_payable')
      },
      prop: 'tbcAmount',
      width: '120',
    },
    {
      get label() {
        return t('amount_paid')
      },
      prop: 'amount',
      width: '120',
    },
    { slot: 'enableStart' },
    {
      get label() {
        return t('maturity_day')
      },
      prop: 'enableEnd',
      width: '120',
      sortable: 'custom',
    },
    {
      get label() {
        return t('replenishment_time')
      },
      prop: 'createTime',
      width: '200',
      sortable: 'custom',
    },
    {
      get label() {
        return t('debit_time')
      },
      prop: 'deductDate',
      width: '120',
      sortable: 'custom',
      render: (scope: { row: Record<string, unknown> }) => scope.row['deductDate'] || '--',
    },
    {
      get label() {
        return t('status')
      },
      prop: 'orderEnableStatus',
    },
    {
      get label() {
        return t('auditor')
      },
      prop: 'reviewUserName',
    },
    {
      get label() {
        return t('subscriber')
      },
      prop: 'subTypeName',
    },
    {
      get label() {
        return t('administrator_user_name')
      },
      prop: 'createByName',
      minWidth: '120',
    },
    { slot: 'isGive' },
    { slot: 'oldOrderId' },
    {
      get label() {
        return t('internet_account')
      },
      prop: 'cusNo',
      width: '120',
      sortable: 'custom',
    },
    { slot: 'handler' },
  ],
})

const pagination: Record<string, any> = reactive({
  paginationProps: {
    currentPage: 1,
    pageSize: 20,
    total: 0,
  },
  paginationEvent: {
    onSizeChange: (v: number | string) => {
      pagination.paginationProps.pageSize = v
      getData()
    },
    onCurrentChange: (v: number | string) => {
      pagination.paginationProps.currentPage = v
      getData()
    },
  },
})

const commonFormItems = [
  {
    prop: 'keyword',
    get label() {
      return t('user_account_keyword')
    },
    innerEl: {
      elType: 'input',
      props: {
        get placeholder() {
          return t('please_input_user_name_nickname')
        },
      },
    },
  },
  {
    prop: 'packageId',
    get label() {
      return t('stream_market_package')
    },
    innerEl: {
      elType: 'select',
      options: quoPackagesOptions,
    },
  },
  {
    prop: 'productId',
    get label() {
      return t('quote_market')
    },
    innerEl: {
      elType: 'select',
      options: marketTypeOptions,
    },
  },
  {
    prop: 'subType',
    get label() {
      return t('subscriber')
    },
    innerEl: {
      elType: 'select',
      // options: subTypeSelect,
      options: subTypeOptions,
    },
  },
  {
    prop: 'orderEnableStatus',
    get label() {
      return t('status')
    },
    innerEl: {
      elType: 'select',
      options: orderEnableStatusOptions,
    },
  },
  {
    prop: 'createDate',
    get label() {
      return t('replenishment_time')
    },
    innerEl: { elType: 'datePicke', props: { type: 'daterange', valueFormat: 'YYYY-MM-DD' } },
  },
  {
    prop: 'beginDate',
    get label() {
      return t('debit_time')
    },
    innerEl: { elType: 'datePicke', props: { type: 'daterange', valueFormat: 'YYYY-MM-DD' } },
  },
  {
    prop: 'expireDate',
    get label() {
      return t('expiration_time')
    },
    innerEl: { elType: 'datePicke', props: { type: 'daterange', valueFormat: 'YYYY-MM-DD' } },
  },
]

const filterConfig = reactive({
  formProps: {
    model: {},
  },
  formItems: commonFormItems,
})

// 批量审核
const reviewDialogRef = ref()
const reviewSelection = ref([])

function getData() {
  isLoading.value = true

  const page: Record<string, any> = { type: 1 }
  page.pageNum = pagination.paginationProps.currentPage
  page.pageSize = pagination.paginationProps.pageSize

  if (ordering.value.column) {
    Object.assign(page, {
      orders: [ordering.value],
    })
  }

  const params = Object.assign({}, page, filterConfig.formProps.model)
  // 类型
  params.isGive = tabNames[activeName.value]

  // 格式化时间
  if (params.createDate) {
    params.createDateStart = params.createDate[0]
    params.createDateEnd = params.createDate[1]
    delete params.createDate
  }

  if (params.beginDate) {
    params.enableDateStart = params.beginDate[0]
    params.enableDateEnd = params.beginDate[1]
    delete params.beginDate
  }

  if (params.expireDate) {
    params.expiredDateStart = params.expireDate[0]
    params.expiredDateEnd = params.expireDate[1]
    delete params.expireDate
  }

  orderListReq(formToParams(params))
    .then((res) => {
      tableConfig.tableProps.data = res.result.records
      pagination.paginationProps.currentPage = res.result.current
      pagination.paginationProps.pageSize = res.result.size
      pagination.paginationProps.total = res.result.total
      isLoading.value = false
    })
    .catch((err) => {
      console.log(err)
      isLoading.value = false
    })
}

/** 导出接口 */
const isExportLoading = ref(false)
const exportFunc = async () => {
  isExportLoading.value = true
  const actArr = reviewSelection.value.map((action: any) => action.id)

  const params: any = { ...filterConfig.formProps.model, type: 1, ids: actArr }
  if (ordering.value.column) {
    Object.assign(params, {
      orders: [ordering.value],
    })
  }
  // 类型
  params.isGive = tabNames[activeName.value]
  // 格式化时间
  if (params.createDate) {
    params.createDateStart = params.createDate[0]
    params.createDateEnd = params.createDate[1]
    delete params.createDate
  }
  if (params.beginDate) {
    params.enableDateStart = params.beginDate[0]
    params.enableDateEnd = params.beginDate[1]
    delete params.beginDate
  }
  if (params.expireDate) {
    params.expiredDateStart = params.expireDate[0]
    params.expiredDateEnd = params.expireDate[1]
    delete params.expireDate
  }
  await orderListExpor(params, `${t('order_history_streaming_quote')}.xls`)
  isExportLoading.value = false
}

function searchHandle() {
  getData()
}

function resetHandle() {
  getData()
}

onBeforeMount(() => {
  getData()
})
</script>

<style lang="scss" scoped>
/* stylelint-disable selector-pseudo-class-no-unknown, selector-class-pattern -- Scoped Element Plus overrides. */
.order-record-tabs {
  --el-tabs-header-height: 30px;

  margin-bottom: var(--ui-toolbar-spacing);

  :deep(.el-tabs__header) {
    margin: 0;
  }

  :deep(.el-tabs__nav) {
    gap: var(--ui-section-gap);
  }

  :deep(.el-tabs__nav-wrap::after) {
    height: 1px;
    background: var(--el-border-color-light);
  }

  :deep(.el-tabs__item) {
    padding: 0;
    color: var(--el-text-color-regular);
    font-size: var(--el-font-size-base);
    font-weight: 400;
  }

  :deep(.el-tabs__item.is-active) {
    color: var(--el-color-primary);
    font-weight: 600;
  }

  :deep(.el-tabs__item:hover) {
    color: var(--el-color-primary);
  }

  :deep(.el-tabs__active-bar) {
    height: 2px;
    background: var(--el-color-primary);
  }

  :deep(.el-tabs__nav-next),
  :deep(.el-tabs__nav-prev) {
    line-height: var(--el-tabs-header-height);
  }
}
/* stylelint-enable selector-pseudo-class-no-unknown, selector-class-pattern */

.tool {
  margin-bottom: var(--ui-toolbar-spacing);
}

.audit-button.is-disabled {
  color: var(--el-disabled-text-color) !important;
  cursor: not-allowed;
}
</style>
