<template>
  <el-dialog
    v-model="visible"
    :title="$t(mode === 'review' ? 'immediate_cancel_review' : 'immediate_cancel_title')"
    :width="mode === 'review' ? 'min(720px, calc(100vw - 32px))' : '560px'"
    destroy-on-close
    :close-on-click-modal="false"
    :show-close="!submitting"
    :close-on-press-escape="!submitting"
    @close="requestId++"
  >
    <div v-loading="loading">
      <el-form class="cancel-form" label-width="auto" label-position="right">
        <el-form-item :label="$t('transaction_account') + '：'">{{
          order.tradeAccount || '--'
        }}</el-form-item>
        <el-form-item :label="$t('immediate_cancel_package') + '：'">{{
          order.packageName || '--'
        }}</el-form-item>
        <template v-if="mode === 'review'">
          <el-form-item :label="$t('cancel_applicant') + '：'">{{
            order.rtqCancelApplyUserName || '--'
          }}</el-form-item>
          <el-form-item :label="$t('cancel_reason') + '：'">{{ reasonLabel }}</el-form-item>
          <el-form-item :label="$t('cancel_remark') + '：'">
            <span class="review-remark">{{ form.cancelRemark || '--' }}</span>
          </el-form-item>
          <el-form-item :label="$t('audit_status') + '：'" required>
            <el-radio-group v-model="isPass">
              <el-radio :label="true">{{ $t('audit_approve') }}</el-radio>
              <el-radio :label="false">{{ $t('audit_reject') }}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="$t('review_reason') + '：'">
            <el-input
              v-model="reviewReason"
              type="textarea"
              :rows="3"
              maxlength="200"
              show-word-limit
              :placeholder="$t('review_reason_placeholder')"
            />
          </el-form-item>
        </template>
        <template v-else>
          <el-form-item :label="$t('cancel_reason') + '：'" required>
            <el-select v-model="form.cancelReason" :placeholder="$t('please_select')">
              <el-option
                v-for="item in reasons"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item :label="$t('cancel_remark') + '：'">
            <el-input
              v-model="form.cancelRemark"
              type="textarea"
              :rows="3"
              maxlength="200"
              show-word-limit
              :placeholder="$t('cancel_remark_placeholder')"
            />
          </el-form-item>
        </template>
      </el-form>
    </div>
    <template #footer>
      <CustomDialogFooter>
        <el-button
          class="cancel-action submit-action"
          type="primary"
          :loading="submitting"
          :disabled="
            loading || !loaded || (mode === 'review' ? isPass === null : !form.cancelReason)
          "
          @click="submit"
        >
          {{ $t(mode === 'review' ? 'determine' : 'exchange_submit_review') }}
        </el-button>
        <el-button class="cancel-action" :disabled="submitting" @click="visible = false">
          {{ $t('cancel') }}
        </el-button>
      </CustomDialogFooter>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { useI18n } from 'vue-i18n'
import CustomDialogFooter from '@/components/custom-dialog-footer.vue'
import { fetchDicts, fetchQuotationOrderDetail } from '@/api-v2/quotation/query'
import {
  applyImmediateCancel,
  modifyImmediateCancel,
  reviewImmediateCancel,
} from '@/api-v2/quotation/mutations'

const emit = defineEmits<{ (e: 'callback'): void }>()
const { t } = useI18n()
const visible = ref(false)
const loading = ref(false)
const loaded = ref(false)
const submitting = ref(false)
const mode = ref<'apply' | 'modify' | 'review'>('apply')
const order = ref<Record<string, any>>({})
const reasons = ref<{ value: string; label: string }[]>([])
const form = reactive({ cancelReason: '', cancelRemark: '' })
const isPass = ref<boolean | null>(null)
const reviewReason = ref('')
const reasonLabel = computed(
  () =>
    order.value.rtqCancelReasonName ||
    reasons.value.find((item) => item.value === form.cancelReason)?.label ||
    form.cancelReason ||
    '--'
)
let requestId = 0

async function open(row: Record<string, any>, nextMode: 'apply' | 'modify' | 'review') {
  if (submitting.value) return
  const id = ++requestId
  mode.value = nextMode
  order.value = {}
  form.cancelReason = ''
  form.cancelRemark = ''
  isPass.value = null
  reviewReason.value = ''
  reasons.value = []
  visible.value = true
  loading.value = true
  loaded.value = false
  try {
    const [dict, detail] = await Promise.all([
      fetchDicts(['rtq_cancel_reason']),
      fetchQuotationOrderDetail(row.orderId),
    ])
    if (id !== requestId) return
    reasons.value = (dict.result?.rtq_cancel_reason || []).map(([value, label]) => ({
      value,
      label,
    }))
    order.value = detail.result
    form.cancelReason = nextMode === 'apply' ? '' : order.value.rtqCancelReason || ''
    form.cancelRemark = nextMode === 'apply' ? '' : order.value.rtqCancelRemark || ''
    loaded.value = true
  } catch (error) {
    console.error('Failed to load cancellation details', error)
  } finally {
    if (id === requestId) loading.value = false
  }
}

async function submit() {
  if (submitting.value || loading.value || !loaded.value) return
  if (mode.value === 'review' ? isPass.value === null : !form.cancelReason) return
  const reason = mode.value === 'review' ? reviewReason.value : form.cancelRemark
  if (reason.length > 200) {
    ElMessage.warning(t('reason_length_limit'))
    return
  }
  submitting.value = true
  try {
    if (mode.value === 'review') {
      await reviewImmediateCancel({
        orderId: order.value.orderId,
        isPass: isPass.value as boolean,
        reviewReason: reviewReason.value,
      })
    } else {
      const params = {
        orderId: order.value.orderId,
        rtqCancelReason: form.cancelReason,
        rtqCancelRemark: form.cancelRemark,
      }
      await (mode.value === 'modify' ? modifyImmediateCancel(params) : applyImmediateCancel(params))
    }
    visible.value = false
    ElMessage.success(t('operation_success'))
    emit('callback')
  } catch (error) {
    console.error('Failed to submit cancellation', error)
  } finally {
    submitting.value = false
  }
}
defineExpose({ open })
</script>

<style scoped>
.cancel-form {
  --ui-control-width: 100%;
}

.review-remark {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

.cancel-action {
  min-width: 120px;
  max-width: 100%;
  width: auto;
}
</style>
