<script setup lang="ts">
import { reactive, onBeforeMount } from 'vue'
import { useI18n } from 'vue-i18n'
import baseFilter from '@/components/base-filter/base-filter'
import dzTable from '@/components/dz-table/dz-table'

const { t } = useI18n()

// 行情套餐
const setMealSelect = [
  {
    get label() {
      return t('stream_market_package')
    },
    value: '1',
  },
]

// 所属机构
const institution = [
  {
    get label() {
      return t('theInstitution')
    },
    value: '1',
  },
]

// 表单配置
const formItems = [
  {
    prop: 't1',
    get label() {
      return t('registration_time')
    },
    innerEl: { elType: 'datePicke', props: { type: 'daterange' } },
  },
  {
    prop: 't2',
    get label() {
      return t('market_package')
    },
    innerEl: {
      elType: 'select',
      options: setMealSelect,
    },
  },
  {
    prop: 't3',
    get label() {
      return t('theInstitution')
    },
    innerEl: {
      elType: 'select',
      options: institution,
    },
  },
  {
    prop: 't4',
    get label() {
      return t('user_search_keyword')
    },
    innerEl: {
      elType: 'input',
      props: {
        get placeholder() {
          return t('please_enter_user_search_keyword')
        },
      },
    },
  },
]

const tableConfig: Record<string, any> = reactive({
  tableProps: {
    data: [],
    height: '580',
  },
  customColumns: [
    {
      get label() {
        return t('middleground_account')
      },
      prop: 'a',
    },
    {
      get label() {
        return t('fullName')
      },
      prop: 'd',
    },
    {
      get label() {
        return t('nickname')
      },
      prop: 'e',
    },
    {
      get label() {
        return t('mobile_number')
      },
      prop: 'f',
    },
    {
      get label() {
        return t('stock_symbol_name')
      },
      prop: 'e',
    },
    {
      get label() {
        return t('belongs_market')
      },
      prop: 'e',
    },
    {
      get label() {
        return t('device_number')
      },
      prop: 'b',
    },
    {
      get label() {
        return t('client')
      },
      prop: 'e',
    },
    {
      get label() {
        return t('version_number')
      },
      prop: 'b',
    },
    {
      get label() {
        return t('operating_system')
      },
      prop: 'b',
    },
    {
      get label() {
        return t('ip_address')
      },
      prop: 'g',
    },
    {
      get label() {
        return t('country_region')
      },
      prop: 'h',
    },
    {
      get label() {
        return t('operation_time')
      },
      prop: 'j',
    },
  ],
})

/** 导出接口 */
function exportFunc() {
  console.log(t('export'))
}

/**
 * 获取表格数据
 * @param data 传入数据
 */
function getData() {
  tableConfig.tableProps.data = new Array(10).fill({
    a: '2016-05-03',
    b: 'Tom',
    c: 'No. 189, Grove St, Los Angeles',
    d: 'No. 189, Grove St, Los Angeles',
    e: 'No. 189, Grove St, Los Angeles',
    f: 'No. 189, Grove St, Los Angeles',
    g: 'No. 189, Grove St, Los Angeles',
    h: 'No. 189, Grove St, Los Angeles',
    i: 'No. 189, Grove St, Los Angeles',
    j: 'No. 189, Grove St, Los Angeles',
  })
}

const pagination = reactive({
  paginationProps: {
    currentPage: 1,
    pageSize: 10,
    total: 100,
  },
  paginationEvent: {
    onSizeChange: (v: number | string) => {
      console.log(v)
    },
    onCurrentChange: (v: number | string) => {
      console.log(v, '---------- current')
    },
  },
})

/** 表单数据 */
const filterConfig = reactive({
  formProps: {
    model: {
      registerTime: '',
      registerSource: '',
      status: '',
      account: '',
    },
  },
  // eslint-disable-next-line no-use-before-define
  formItems,
})

function searchHandle() {
  getData()
}

function resetHandle() {
  getData()
}

onBeforeMount(() => {
  getData()
})
</script>

<template>
  <el-card>
    <el-button size="small" class="export-button" @click="exportFunc">{{ $t('export') }}</el-button>
    <base-filter :config="filterConfig" @on-search="searchHandle" @on-reset="resetHandle" />
    <div class="table">
      <dz-table :config="tableConfig" :pagination="pagination" />
    </div>
  </el-card>
</template>
