<template>
  <!-- 上报报表-员工表 -->
  <div class="page-container">
    <div class="filter-box">
      <baseFilter
        :loading="isLoading"
        :config="formConfig"
        @on-search="handle(true)"
        @on-reset="handle(false)"
      />
    </div>

    <div class="operate-buttons">
      <el-button plain :loading="isExportLoading" class="export-button" @click="exportData">{{
        t('export')
      }}</el-button>
    </div>

    <baseTable :config="tableConfig" :pagination="pagination" :is-loading="isLoading"> </baseTable>
  </div>
</template>
<script lang="ts" setup>
import { reactive, ref, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { useI18n } from 'vue-i18n'
import ConfigType from '@/types/requestType'
import baseFilter from '@/components/base-filter/base-filter'
import baseTable from '@/components/base-table/base-table'
import useTableData from '@/hooks/useTableData'
import { cloneDeep } from '@/utils/common'
// import { settleExchangeRateExport } from '@/api/revenue/settle-mange'
const { t } = useI18n()

const isExportLoading = ref(false)

// 列表请求参数
const reqConfig = reactive<ConfigType>({
  url: '/dtc/settleExchangeRate/list',
  method: 'POST',
  data: {
    exchangeCode: 'HKEX',
    orders: [
      {
        asc: false,
        column: 'createTime',
      },
    ],
  },
})
// 排序
const ordering = ref({
  asc: false,
  column: 'createTime',
})

// 表格
const { pagination, tableData, loading: isLoading } = useTableData(reqConfig)
const tableConfig = reactive({
  tableProps: {
    data: tableData,
  },
  tableEvent: {
    onSortChange: (column: Record<string, any>) => {
      ordering.value.column = ''
      pagination.paginationProps.currentPage = 1
      const { order, prop } = column
      if (order && prop) {
        const propArr: string[] = prop.split('.')
        const attribute = propArr.length === 1 ? propArr[0] : propArr[1]
        ordering.value = {
          asc: order === 'ascending',
          column: attribute,
        }
      }
      return handle(true)
    },
  },
  customColumns: [
    {
      get label() {
        return t('staff_units_purpose')
      },
      width: '200',
    },
    {
      get label() {
        return t('staff_name')
      },
      prop: 'createTime',
      width: '200',
    },
    {
      get label() {
        return t('staff_dept_position')
      },
      prop: 'clientAccCode',
      width: '200',
    },
    {
      get label() {
        return t('staff_device_user_id')
      },
      prop: 'gbNames',
      width: '200',
    },
    {
      get label() {
        return t('staff_device_type')
      },
      prop: 'engNames',
      width: '200',
    },
    {
      get label() {
        return t('staff_quantity')
      },
      prop: 'engNames',
      width: '200',
    },
    {
      get label() {
        return t('staff_start_date')
      },
      prop: 'engNames',
      width: '200',
    },
    {
      get label() {
        return t('staff_end_date')
      },
      prop: 'engNames',
      width: '200',
    },
    { label: 'Country Code', prop: 'engNames', width: '200' },
    {
      get label() {
        return t('staff_location')
      },
      prop: 'engNames',
      width: '200',
    },
    {
      label:
        'Marketing Agent/ Third Party Provider/ Other Remarks (If the Unit was provided to Marketing Agent  or Third Party Service Agent, please state their names here)',
      prop: 'engNames',
      width: '300',
    },
  ],
})

// 查询条件
const formConfig = reactive({
  formProps: {
    model: {
      exchangeCode: 'HKEX',
    },
  },
  formItems: [
    {
      prop: 'date',
      get label() {
        return t('reporting_month')
      },
      innerEl: {
        elType: 'datePicke',
        props: { type: 'daterange', 'value-format': 'YYYY-MM-DD' },
      },
    },
    {
      prop: 'keyword',
      innerEl: {
        elType: 'input',
        props: {
          get placeholder() {
            return t('please_enter_user_account_keywords')
          },
          clearable: true,
        },
      },
    },
    {
      prop: 'status',
      innerEl: {
        elType: 'select',
        props: {
          get placeholder() {
            return t('equipment_category')
          },
          clearable: true,
        },
        options: [],
      },
    },
    {
      prop: 'status',
      innerEl: {
        elType: 'select',
        props: {
          get placeholder() {
            return t('department_and_position')
          },
          clearable: true,
        },
        options: [],
      },
    },
    {
      prop: 'status',
      innerEl: {
        elType: 'select',
        props: {
          get placeholder() {
            return t('country_code')
          },
          clearable: true,
        },
        options: [],
      },
    },
  ],
})

// 查询
const handle = (flag: boolean) => {
  console.log('=====>查询')
  const page: Record<string, any> = {}
  page.pageNum = pagination.paginationProps.currentPage
  page.pageSize = pagination.paginationProps.pageSize

  if (ordering.value.column) {
    Object.assign(page, {
      orders: [ordering.value],
    })
  }

  let params = {}
  if (!flag) {
    params = Object.assign({ exchangeCode: 'HKEX' }, page)
  } else {
    let modelData: any = { exchangeCode: 'HKEX' }
    Object.keys(formConfig.formProps.model).forEach((k) => {
      if (formConfig.formProps.model[k] !== '') {
        modelData[k] = formConfig.formProps.model[k]
      }
    })
    params = Object.assign({}, page, modelData)
  }

  reqConfig.data = cloneDeep(params)
}

// 导出
const exportData = async () => {
  isExportLoading.value = true
  const params = {
    ...formConfig.formProps.model,
    exchangeCode: 'HKEX',
    pageSize: pagination.paginationProps.total,
    pageNum: 1,
  }

  delete params?.date
  if (ordering.value.column) {
    Object.assign(params, {
      orders: [ordering.value],
    })
  }
  console.log('params', params)
  await settleExchangeRateExport({ ...params }, `${t('Exchange_fee_settlement_list')}.xlsx`) // Exchange_fee_settlement_list '交易所费用结算列表.xlsx'
  isExportLoading.value = false
}
</script>

<style lang="scss" scoped>
:deep(.el-form .el-form-item .el-form-item__content > .el-input) {
  width: 300px;
}
// :deep(.el-input__wrapper) {
//   width: 250px;
// }
</style>
