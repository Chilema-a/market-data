<template>
  <el-card>
    <div class="filter-box">
      <baseFilter
        :loading="isLoading"
        :config="formConfig"
        @on-search="handle(true)"
        @on-reset="handle(false)"
      />
    </div>

    <div class="operate-buttons">
      <el-button
        plain
        v-permission="'statistics:report:export'"
        :loading="isExportLoading"
        class="export-button"
        @click="exportData"
        >{{ t('export') }}</el-button
      >
    </div>
    <baseTable :config="tableConfig" :pagination="pagination" :is-loading="isLoading">
      <template #identity>
        <el-table-column width="120">
          <template #header>
            <div>User Status</div>
            <div>{{ t('identity') }}</div>
          </template>
          <template #default="scope">
            <div>
              <span v-if="scope.row.isPi">{{ t('professional_investor') }}</span>
              <span v-else>{{ t('non_professional_investor') }}</span>
            </div>
          </template>
        </el-table-column>
      </template>
      <template #price>
        <el-table-column width="180">
          <template #header>
            <div>Reference Subscriber Fee per unit($)</div>
            <div>{{ t('reference_quotation_per_unit1') }}</div>
            <div>{{ t('reference_quotation_per_unit2') }}</div>
          </template>
          <template #default="scope">
            <div>
              <span>{{ scope.row.price }}</span>
            </div>
          </template>
        </el-table-column>
      </template>
    </baseTable>
  </el-card>
</template>
<script setup lang="ts">
import { reactive, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import baseFilter from '@/components/base-filter/base-filter'
import useTableData from '@/hooks/useTableData'
import ConfigType from '@/types/requestType'
import baseTable from '@/components/base-table/base-table'
import { cloneDeep } from '@/utils/common'
import { marketReportExportOrder } from '@/api/quotation'

const { t } = useI18n()
const isExportLoading = ref(false)

// 查询条件
const formConfig = reactive({
  formProps: {
    model: {},
  },
  formItems: [
    {
      prop: 'reportMonth',
      get label() {
        return t('reporting_month')
      },
      innerEl: {
        elType: 'datePicke',
        props: {
          type: 'month',
          'value-format': 'YYYY-MM',
          get placeholder() {
            return t('please_select')
          },
        },
        clearable: true,
      },
    },
  ],
})
// 列表请求参数
const reqConfig = reactive<ConfigType>({
  url: '/quotation/statistics/us/order/detail',
  method: 'POST',
  data: {},
})
// 排序
const ordering = ref({
  asc: false,
  column: 'reportMonth',
})
const { pagination, tableData, loading: isLoading } = useTableData(reqConfig)
const tableConfig = reactive({
  tableProps: {
    data: tableData,
  },
  tableEvent: {
    onSortChange: (column: Record<string, any>) => {
      ordering.value.column = ''
      pagination.paginationProps.currentPage = 1
      const { order, prop } = column
      if (order && prop) {
        const propArr: string[] = prop.split('.')
        const attribute = propArr.length === 1 ? propArr[0] : propArr[1]
        ordering.value = {
          asc: order === 'ascending',
          column: attribute,
        }
      }
      return handle(true)
    },
  },
  customColumns: [
    {
      get label() {
        return `Reporting month ${t('reporting_month')}`
      },
      prop: 'reportMonth',
      width: '150',
    },
    {
      get label() {
        return `Unique Subscriber ID ${t('trading_name')}`
      },
      prop: 'cusNo',
      width: '170',
    },
    {
      get label() {
        return `Subscriber Name ${t('user_name2')}`
      },
      prop: 'userNameEn',
      width: '150',
    },
    // { slot: 'identity' },
    {
      get label() {
        return `Address ${t('address')}`
      },
      prop: 'typeName',
      width: '177',
    },
    {
      get label() {
        return `Region/Country ${t('country_region')}`
      },
      prop: 'number',
      width: '135',
    },
    // {
    //   slot: 'price',
    // },
    {
      get label() {
        return `Date of Service Commenced [D-MMM-YY] ${t('service_start_date')}`
      },
      prop: 'amount',
    },
    {
      get label() {
        return `Date of Service Terminated [D-MMM-YY] ${t('service_end_date')}`
      },
      prop: 'startDate',
    },
  ],
})
const exportData = () => {
  isExportLoading.value = true

  const params = { ...formConfig.formProps.model }

  marketReportExportOrder(params, `${t('us_market_report')}.xls`).then(() => {
    isExportLoading.value = false
  })
}

const handle = (isSearch: boolean) => {
  console.log('++++++++++++++++++', formConfig.formProps.model)

  const page: Record<string, any> = {}
  page.pageNum = pagination.paginationProps.currentPage
  page.pageSize = pagination.paginationProps.pageSize

  if (ordering.value.column) {
    Object.assign(page, {
      orders: [ordering.value],
    })
  }

  let params = {}
  if (!isSearch) {
    params = Object.assign({}, page)
  } else {
    // let modelData: Record<string, any> = {}
    const data: any = formConfig.formProps.model
    params = Object.assign({}, page, data)
  }

  reqConfig.data = cloneDeep(params)
}

const handleDetails = () => {}
</script>
<style lang="scss">
:deep(.cell) {
  background-color: red;
  color: #fff !important;
}
</style>
