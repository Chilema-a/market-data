<script setup lang="ts">
import { reactive, onBeforeMount, ref, computed } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage } from 'element-plus'
import baseFilter from '@/components/base-filter/base-filter'

// 套餐列表

import { cloneDeep, timeDiff } from '@/utils/common'
import useTableData from '@/hooks/useTableData'
import dzTable from '@/components/dz-table/dz-table'
import ConfigType from '@/types/requestType'
import { SelectOptions } from '@/types'
import { exportUnifiedReport, fetchPackageOptions } from '@/api-v2/quotation/query'

const { t } = useI18n()

// #region options
const packageOptions = ref<SelectOptions>([])
enum ExpiredDateType {
  Empty = 1,
  EmptyAndPreviousMonth = 2,
  SpecificDateRange = -1,
}

const expiredDateTypeOptions = ref<SelectOptions<number>>([
  {
    get label() {
      return t('empty')
    },
    value: ExpiredDateType.Empty,
  },
  {
    get label() {
      return t('empty_and_previous_month')
    },
    value: ExpiredDateType.EmptyAndPreviousMonth,
  },
  {
    get label() {
      return t('specific_date_range')
    },
    value: ExpiredDateType.SpecificDateRange,
  },
])

function initDicts() {
  fetchPackageOptions(1).then((res) => {
    packageOptions.value = res.result.map((v: any) => ({
      label: `${v.packageName}-${v.rtq} (R6 RTQ)-${v.packageId}`,
      value: v.packageId,
    }))
  })
}
// #endregion

onBeforeMount(() => {
  initDicts()
})

// #region table

const ordering = reactive<Record<string, any>>({
  asc: true,
  column: '',
})

const reqConfig = reactive<ConfigType>({
  url: '/quotation/report/unify/list',
  method: 'POST',
  data: {},
})

// 选中行数
let tableSelectionRows: any[] = []
const tableSelectionChange = (selection: []) => {
  tableSelectionRows = selection
}

const { tableData, pagination, loading } = useTableData(reqConfig)

function getSearchParams() {
  const params: Record<string, any> = cloneDeep(filterConfig.formProps.model)
  if (params.enableDate) {
    const [startDate, endDate] = params.enableDate
    params.enableDateStart = startDate
    params.enableDateEnd = endDate
  }

  if (!params.selectType || useSpecificDateRange.value) {
    delete params.selectType
  }

  if (useSpecificDateRange.value && params.expireDate) {
    const [startDate, endDate] = params.expireDate
    params.expireDateStart = startDate
    params.expireDateEnd = endDate
  }

  delete params.expireDate
  delete params.enableDate

  if (ordering.column) {
    params.orders = [ordering]
  }

  return params
}

const searchDataList = () => {
  reqConfig.data = getSearchParams()
}

// #endregion
const tableConfig = reactive({
  tableProps: {
    data: tableData,
    height: '580',
  },
  tableEvent: {
    onSelectionChange: tableSelectionChange,
    onSortChange: (column: Record<string, any>) => {
      const { order, prop } = column
      ordering.column = prop
      if (!order) {
        ordering.column = undefined
        ordering.asc = undefined
      } else {
        ordering.asc = order === 'ascending' ? true : false
      }
      searchDataList()
    },
  },
  customColumns: [
    { label: 'Client ID', prop: 'tradeAccount', width: 100 },
    { label: 'Name', prop: 'userName' },
    { label: 'Account Type', prop: 'accountTypeName' },
    {
      get label() {
        return t('qutoe_package_name')
      },
      prop: 'packageName',
    },
    { label: 'Plan id（R6 RTQ）', prop: 'rtq', minWidth: 100 },
    {
      get label() {
        return t('plan_id_dz')
      },
      prop: 'packageId',
      minWidth: 140,
    },
    { label: 'Vip flag', prop: 'isGiveFlag' },
    { label: 'Application submit date', prop: 'createTime', width: 200 },
    { label: 'Plan start date', prop: 'enableStart', width: 200 },
    { label: 'Plan end date', prop: 'enableEnd', width: 200 },
    { label: 'Terminate  Date', prop: 'terminateDate', width: 200 },
    { label: 'Terminate Reason', prop: 'cancelReasonName', width: 200 },
    { label: 'Address', prop: 'address', width: 200 },
    { label: 'XET login times(during the period）', prop: 'useCount', width: 200 },
    { label: 'Remark', prop: 'remark', width: 100 },
  ],
})

// #region filter form

// 表单配置
const formItems = [
  {
    prop: 'packageId',
    get label() {
      return t('package_name')
    },
    innerEl: {
      elType: 'select',
      options: packageOptions,
      props: {
        get placeholder() {
          return t('please_select')
        },
      },
    },
  },
  {
    prop: 'enableDate',
    label: 'Plan start date',
    innerEl: { elType: 'datePicke', props: { type: 'daterange', valueFormat: 'YYYY-MM-DD' } },
  },
  {
    slot: 'expireDate',
  },
]

/** 表单数据 */
const filterConfig = reactive({
  formProps: {
    model: {
      enableDate: [],
      expireDate: [],
      packageId: '',
      selectType: undefined as number | undefined,
    },
  },
  formItems,
})

// #endregion

/** 导出接口 */
const isExportLoading = ref(false)
function exportFunc() {
  const { enableDate = [] } = filterConfig.formProps.model
  if (!enableDate || !enableDate.length) {
    ElMessage.warning(t('export_message'))
    return
  }

  const [beginTime, endTime] = enableDate
  if (timeDiff(beginTime, endTime)) {
    ElMessage.warning(t('export_month_message'))
    return
  }

  isExportLoading.value = true

  const params = getSearchParams()

  exportUnifiedReport(params).finally(() => {
    isExportLoading.value = false
  })
}

const dialogRef = ref()

function openMarketAuthorizationDetail(row: Record<string, any>) {
  dialogRef.value.open(row.tradeAccount)
}

const useSpecificDateRange = computed(() => {
  return filterConfig.formProps.model.selectType === ExpiredDateType.SpecificDateRange
})
</script>

<template>
  <el-card>
    <base-filter
      :loading="loading"
      :config="filterConfig"
      @on-search="searchDataList"
      @on-reset="searchDataList"
    >
      <template #expireDate>
        <el-form-item :label="$t('package_end_date')" class="expiry-filter">
          <el-select
            v-model="filterConfig.formProps.model.selectType"
            :options="expiredDateTypeOptions"
            clearable
            :placeholder="$t('please_select')"
          ></el-select>
          <el-date-picker
            v-model="filterConfig.formProps.model.expireDate"
            :disabled="!useSpecificDateRange"
            type="daterange"
            value-format="YYYY-MM-DD"
            :range-separator="$t('range_to')"
            :start-placeholder="$t('start_date')"
            :end-placeholder="$t('end_date')"
          />
        </el-form-item>
      </template>
    </base-filter>
    <div class="operate-buttons">
      <el-button
        plain
        v-permission="'quo:unify:list:export'"
        type="primary"
        size="small"
        :loading="isExportLoading"
        class="export-button"
        @click="exportFunc"
        >{{ $t('export') }}</el-button
      >
    </div>
    <div class="table">
      <dzTable :config="tableConfig" :pagination="pagination" :is-table-loading="loading">
        <!-- <template #meal>
          <el-table-column :label="$t('market_package_text')" align="center">
            <template #default="scope">
              <div v-permission:disabled="'order:auto:renew'" style="color: blue; cursor: pointer">
                <span
                  v-for="(item, i) in scope.row.orders"
                  :key="i"
                  class="market-package"
                  @click="openOrderSetting(scope.row, item)"
                >
                  {{ item.packageName }}
                </span>
              </div>
            </template>
          </el-table-column>
        </template> -->

        <template #tradeAccount>
          <el-table-column :label="$t('trading_account')" align="center">
            <template #default="scope">
              <div>
                {{ scope.row.tradeAccount }}
              </div>
            </template>
          </el-table-column>
        </template>

        <template #marketAuthorization>
          <el-table-column :label="$t('market_authorization')" align="center">
            <template #default="scope">
              <el-button type="text" size="small" @click="openMarketAuthorizationDetail(scope.row)">
                {{ $t('details') }}
              </el-button>
            </template>
          </el-table-column>
        </template>
      </dzTable>
    </div>
  </el-card>
</template>

<style scoped lang="scss">
/* stylelint-disable selector-class-pattern, selector-pseudo-class-no-unknown -- Element Plus and Vue scoped selectors. */
.expiry-filter :deep(.el-form-item__content) {
  width: 490px;
  max-width: 100%;
  flex: 0 1 490px;
  gap: 10px;

  > .el-select {
    width: 160px !important;
    min-width: 0 !important;
    flex: 0 1 160px;
  }

  > .el-date-editor {
    width: 300px !important;
    min-width: 0 !important;
    flex: 1 1 260px;
  }
}

.market-package {
  display: block;
}
</style>
