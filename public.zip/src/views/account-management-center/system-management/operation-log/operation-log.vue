<template>
  <div class="page-container">
    <baseFilter
      :loading="isLoading"
      :config="filterConfig"
      @onSearch="searchHandle"
      @onReset="resetHandle"
    ></baseFilter>
    <div class="operate-buttons">
      <el-button
        plain
        type="primary"
        class="export-button"
        :loading="exportLoading"
        @click="toExport"
        v-permission="'sys:operationLog:export'"
        >{{ $t('export') }}</el-button
      >
    </div>
    <baseTable
      ref="tablePaginationRef"
      :config="tableConfig"
      :pagination="paginationConfig"
      :isTableLoading="isLoading"
    >
      <template v-slot:operateExplain>
        <el-table-column :label="$t('operation_data')" align="center">
          <template #default="{ row }">
            <span v-if="row.data.length > 32">
              <span>{{ row.data.substring(0, 32) + '...' }}</span>
              <span @click="showAllSize(row)" class="allShow">{{ $t('expand_filters') }}</span>
            </span>
            <span v-else>{{ row.data }}</span>
          </template>
        </el-table-column>
      </template>
      <template v-slot:status>
        <el-table-column :label="$t('operate_status')" align="center">
          <template #default="scope">
            {{ scope.row.status ? $t('succeed') : $t('failure') }}
          </template>
        </el-table-column>
      </template>
    </baseTable>
    <el-dialog
      v-model="isShowDialog"
      width="30%"
      :title="$t('operation_data')"
      center
      append-to-body
    >
      <div>{{ tableConfig.showValue }}</div>
      <template #footer>
        <el-button @click="isShowDialog = false">{{ $t('close') }}</el-button>
      </template>
    </el-dialog>
  </div>
</template>
<script lang="ts">
import { defineComponent, reactive, ref } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElMessage, ElMessageBox } from 'element-plus'
import baseFilter from '@/components/base-filter/base-filter'
import baseTable from '@/components/base-table/base-table'
import { timeDiff } from '@/utils/common'
import { getUserOperationLog, loginLogExport, operationLogExport } from '@/api/subPro/subPro'

export default defineComponent({
  name: 'account-operation-log',
  components: {
    baseFilter,
    baseTable,
  },
  setup() {
    const { t } = useI18n()
    const tablePaginationRef = ref()
    const pageSize = ref(20)
    const currentPage = ref(1)
    const isShowDialog = ref<boolean>(false)
    const searchData = ref()
    const isLoading = ref<boolean>(false)
    const ordering = ref({
      asc: true,
      column: '',
    })

    /* 表格-start */
    const tableConfig = reactive({
      showValue: '',
      tableProps: {
        data: <{ date: string; name: string; address: string }[]>[],
      },
      tableEvent: {
        onSortChange: (column: Record<string, any>) => {
          const { order, prop } = column
          ordering.value.column = ''
          currentPage.value = 1
          paginationConfig.value.paginationProps.currentPage = 1

          if (order) {
            ordering.value = {
              asc: order === 'ascending',
              column: prop,
            }
          }
          return toGetUserLoginLog()
        },
      },
      customColumns: [
        {
          get label() {
            return t('login_account')
          },
          prop: 'username',
        },
        {
          get label() {
            return t('fullName')
          },
          prop: 'nickname',
        },
        {
          get label() {
            return t('business_module')
          },
          prop: 'moduleName',
        },
        {
          get label() {
            return t('operation_name')
          },
          prop: 'name',
        },
        // { label: '操作数据', prop: 'data' },
        { slot: 'operateExplain' },
        {
          get label() {
            return t('operation_description')
          },
          prop: 'remark',
        },
        // { label: '操作状态', prop: 'status' },
        { slot: 'status' },
        {
          get label() {
            return t('ip_address')
          },
          prop: 'ip',
        },
        {
          get label() {
            return t('operate_time')
          },
          prop: 'createTime',
        },
      ],
    })
    const statusText = (num: number) => {
      const text = [t('failure'), t('success')]
      return text[num]
    }
    /* 表格-end */

    /* 分页-start */
    const paginationConfig = ref({
      paginationProps: { total: 0, 'page-size': 20, currentPage: 1 },
      paginationEvent: {
        onSizeChange: handleSizeChange,
        onCurrentChange: handleCurrentChange,
      },
    })
    function handleSizeChange(currentSize: number) {
      paginationConfig.value.paginationProps['page-size'] = currentSize
      tablePaginationRef.value?.toFirstPage()
      currentPage.value = 1
      pageSize.value = currentSize
      toGetUserLoginLog()
    }
    function handleCurrentChange(theCurrentPage: number) {
      currentPage.value = theCurrentPage
      paginationConfig.value.paginationProps.currentPage = theCurrentPage
      toGetUserLoginLog()
    }
    /* 分页-end */

    function toGetUserLoginLog() {
      isLoading.value = true
      const params = {
        ...searchData.value,
        pageSize: pageSize.value,
        pageNum: currentPage.value,
      }

      if (ordering.value.column) {
        Object.assign(params, {
          orders: [ordering.value],
        })
      }

      getUserOperationLog(params)
        .then((res: { [key: string]: any }) => {
          tableConfig.tableProps.data = res.result?.records
          paginationConfig.value.paginationProps.total = res.result?.total || 0
        })
        .finally(() => {
          isLoading.value = false
        })
    }
    toGetUserLoginLog()

    /* 过滤表单-start */
    const filterConfig = ref({
      formProps: {
        model: {
          loginTime: '',
          status: '',
          keyword: '',
        },
      },
      formItems: [
        {
          prop: 'loginTime',
          get label() {
            return t('operate_time')
          },
          innerEl: {
            elType: 'datePicke',
            props: { type: 'daterange', 'value-format': 'YYYY-MM-DD' },
          },
        },
        {
          prop: 'status',
          get label() {
            return t('operate_status')
          },
          innerEl: {
            elType: 'select',
            options: [
              {
                value: '',
                get label() {
                  return t('all')
                },
              },
              {
                get label() {
                  return t('success')
                },
                value: 1,
              },
              {
                get label() {
                  return t('failure')
                },
                value: 0,
              },
            ],
          },
        },
        {
          prop: 'keyword',
          label: '',
          innerEl: {
            elType: 'input',
            props: {
              get placeholder() {
                return t('please_enter_keyword')
              },
            },
          },
        },
      ],
    })
    const searchHandle = (data: { [name: string]: any }) => {
      currentPage.value = 1
      tablePaginationRef.value?.toFirstPage()
      // 携带自定义插槽数据并请求查询
      const { loginTime, ...params } = data
      const [beginTime, endTime] = loginTime
      searchData.value = { beginTime, endTime, ...params }
      toGetUserLoginLog()
    }
    const resetHandle = (data: { [name: string]: any }) => {
      currentPage.value = 1
      tablePaginationRef.value?.toFirstPage()
      // 重置自定义插槽数据并请求查询
      const { loginTime, ...params } = data
      const [beginTime, endTime] = loginTime
      searchData.value = { beginTime, endTime, ...params }
      toGetUserLoginLog()
    }
    /*  点击展开弹框 */
    const showAllSize = (row: any) => {
      tableConfig.showValue = row.data
      isShowDialog.value = true
    }
    /* 过滤表单-end */

    // 导出
    const exportLoading = ref(false)
    const toExport = () => {
      const params = {
        ...searchData.value,
        pageSize: pageSize.value,
        pageNum: currentPage.value,
      }

      if (ordering.value.column) {
        Object.assign(params, {
          orders: [ordering.value],
        })
      }

      if (!params.beginTime && !params.endTime) {
        ElMessage.warning(t('export_message'))
        return
      }

      if (timeDiff(params.beginTime, params.endTime)) {
        ElMessage.warning(t('export_month_message'))
        return
      }

      exportLoading.value = true
      operationLogExport(params, t('operation_log_export') + '.xlsx').then(() => {
        exportLoading.value = false
      })
    }
    return {
      tablePaginationRef,
      tableConfig,
      paginationConfig,
      statusText,
      filterConfig,
      searchHandle,
      resetHandle,
      isLoading,
      toExport,
      exportLoading,
      showAllSize,
      isShowDialog,
    }
  },
})
</script>
<style lang="scss" scoped>
:deep(.allShow) {
  color: #d20a10;
  margin-left: 5px;
  cursor: pointer;
}
:deep(.el-form-item__content) {
  min-width: 100px;
}
</style>
