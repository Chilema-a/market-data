<template>
  <div class="page-container">
    <div class="operate-buttons">
      <el-button plain class="export-button">{{ $t('export') }}</el-button>
    </div>
    <baseTable ref="tablePaginationRef" :config="tableConfig" :pagination="paginationConfig">
    </baseTable>
  </div>
</template>
<script lang="ts">
import { i18n } from '@/global/register-i18n'

import { defineComponent, reactive, ref } from 'vue'
// import baseFilter from '@/components/base-filter/base-filter'
import baseTable from '@/components/base-table/base-table'
import { getUserOperationLog } from '@/api/subPro/subPro'

const t = i18n.global.t

export default defineComponent({
  name: 'account-operation-log',
  components: {
    // baseFilter,
    baseTable,
  },
  setup() {
    const tablePaginationRef = ref()
    const pageSize = ref(20)
    const currentPage = ref(1)
    const searchData = ref()

    /* 表格-start */
    const tableConfig = reactive({
      tableProps: {
        data: <{ date: string; name: string; address: string }[]>[],
      },
      tableEvent: {},
      customColumns: [
        {
          get label() {
            return t('login_account')
          },
          prop: 'username',
        },
        {
          get label() {
            return t('fullName')
          },
          prop: 'nickname',
        },
        {
          get label() {
            return t('operation_name')
          },
          prop: 'remark',
        },
        {
          get label() {
            return t('operate_status')
          },
          prop: 'status',
        },
        {
          get label() {
            return t('ip_address')
          },
          prop: 'ip',
        },
        {
          get label() {
            return t('operate_time')
          },
          prop: 'createTime',
        },
        // { slot: 'operate' }
      ],
    })
    /* 表格-end */

    /* 分页-start */
    const paginationConfig = ref({
      paginationProps: { total: 0, 'page-size': 20 },
      paginationEvent: {
        onSizeChange: handleSizeChange,
        onCurrentChange: handleCurrentChange,
      },
    })
    function handleSizeChange(currentSize: number) {
      paginationConfig.value.paginationProps['page-size'] = currentSize
      tablePaginationRef.value?.toFirstPage()
      currentPage.value = 1
      pageSize.value = currentSize
      // toGetUserRoleList()
    }
    function handleCurrentChange(theCurrentPage: number) {
      currentPage.value = theCurrentPage
      // toGetUserRoleList()
    }
    /* 分页-end */

    function toGetUserOperationLog() {
      const params = {
        ...searchData.value,
        pageSize: pageSize.value,
        pageNum: currentPage.value,
      }
      getUserOperationLog(params).then((res: { [key: string]: any }) => {
        tableConfig.tableProps.data = res.result?.records
        paginationConfig.value.paginationProps.total = res.result?.total || 0
      })
    }
    toGetUserOperationLog()

    return {
      tableConfig,
      paginationConfig,
    }
  },
})
</script>
