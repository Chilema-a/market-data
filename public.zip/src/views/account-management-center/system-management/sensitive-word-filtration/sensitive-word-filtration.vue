<template>
  <div class="page-container">
    <div class="filter-box">
      <baseFilter
        :loading="isLoading"
        :config="formConfig"
        @on-search="handle(true)"
        @on-reset="handle(false)"
      />
    </div>
    <div class="operate-buttons">
      <el-button class="toolbar-add-button" type="primary" @click="openAdd">{{
        t('new')
      }}</el-button>
      <el-button plain :disabled="!selectedRow.length">{{ $t('batch_deleted') }}</el-button>
      <el-button plain class="export-button" :disabled="!selectedRow.length">{{
        t('export')
      }}</el-button>
      <el-button plain>{{ $t('import') }}</el-button>
    </div>
    <baseTable :config="tableConfig" :pagination="pagination" :is-loading="isLoading">
      <template #operate>
        <el-table-column :label="$t('operate')" align="center" fixed="right" width="320">
          <template #default="scope">
            <el-space>
              <action-confirm :title="$t('confirm_delete')" @confirm="handlerDelete">
                <template #reference>
                  <span class="text-primary mr10">{{ $t('delete') }}</span>
                </template>
              </action-confirm>
            </el-space>
          </template>
        </el-table-column>
      </template>
    </baseTable>

    <AddDialog ref="addDialogRef" />
  </div>
</template>

<script lang="ts" setup>
import { reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { useI18n } from 'vue-i18n'
import baseFilter from '@/components/base-filter/base-filter'
import baseTable from '@/components/base-table/base-table'
import useTableData from '@/hooks/useTableData'
import { cloneDeep } from '@/utils/common'
import AddDialog from './components/add-dialog/add-dialog.vue'

const { t } = useI18n()

const addDialogRef = ref()

// 列表请求参数
const reqConfig = reactive({
  url: '/myCoupon/page',
  method: 'POST',
  data: {},
})
// 排序
const ordering = ref({
  asc: true,
  column: '',
})
const selectedRow = ref<any>([])
// 表格
const { pagination, tableData, loading: isLoading } = useTableData(reqConfig)
const tableConfig = reactive({
  tableProps: {
    data: [
      {
        get word() {
          return t('sensitive_word_example')
        },
      },
    ],
  },
  tableEvent: {
    onSelectionChange: (val: { map: (arg0: (item: { id: any }) => any) => never[] }) => {
      console.log('val======>', val)
      selectedRow.value = val
      // isEnableStatus.value = selectedRow.value.some(
      //   (item: { isEnable: any }) => item.isEnable === 0
      // )
      // isDisableStatus.value = selectedRow.value.some(
      //   (item: { isEnable: any }) => item.isEnable === 1
      // )
    },
    onSortChange: (column: Record<string, any>) => {
      ordering.value.column = ''
      pagination.paginationProps.currentPage = 1
      const { order, prop } = column
      if (order && prop) {
        const propArr: string[] = prop.split('.')
        const attribute = propArr.length === 1 ? propArr[0] : propArr[1]
        ordering.value = {
          asc: order === 'ascending',
          column: attribute,
        }
      }
      return handle(true)
    },
  },
  customColumns: [
    { type: 'selection', align: 'center' },
    {
      get label() {
        return t('sensitive_word')
      },
      prop: 'word',
    },
    {
      get label() {
        return t('created_by')
      },
      prop: 'combinationId',
    },
    {
      get label() {
        return t('creation_time')
      },
      prop: 'combinationId',
    },
    { slot: 'operate' },
    // {
    //   label: t('is_ranking'),
    //   prop: 'isRanking',
    //   formatter: (r: any, a: any, val: number) => {
    //     return ISRANKINGTYPE.find((item) => item.value === val)?.label
    //   },
    // },
  ],
})

console.log(tableConfig.tableProps.data)

// 查询条件
const formConfig = reactive({
  formProps: {
    model: {},
  },
  formItems: [
    {
      prop: 'word',
      label: '',
      innerEl: {
        elType: 'input',
        props: {
          get placeholder() {
            return t('enter_sensitive_word')
          },
          clearable: true,
        },
      },
    },
  ],
})
// 查询
const handle = (flag: boolean) => {
  const page: Record<string, any> = {}
  page.pageNum = pagination.paginationProps.currentPage
  page.pageSize = pagination.paginationProps.pageSize

  if (ordering.value.column) {
    Object.assign(page, {
      orders: [ordering.value],
    })
  }

  let params = {}
  if (!flag) {
    params = Object.assign({}, page)
  } else {
    let modelData = {}
    Object.keys(formConfig.formProps.model).forEach((k) => {
      if (formConfig.formProps.model[k] !== '') {
        modelData[k] = formConfig.formProps.model[k]
      }
    })
    params = Object.assign({}, page, modelData)
  }

  reqConfig.data = cloneDeep(params)
}

const openAdd = () => {
  addDialogRef.value.handleOpen()
}
const handlerDelete = () => {
  console.log('handlerDelete')
}
// 导出
const exportData = () => {
  console.log(t('export'))
  // isExportLoading.value = true
  // const params = { ...formConfig.formProps.model }
  // if (ordering.value.column) {
  //   Object.assign(params, {
  //     orders: [ordering.value],
  //   })
  // }
  // exportIpoSubManagment({ exportFields: exportArr, ...params }).then((res) => {
  //   const fileName = '可认购管理列表导出.xls'
  //   const link = document.createElement('a')
  //   link.href = window.URL.createObjectURL(res)
  //   link.download = fileName
  //   link.click()
  //   window.URL.revokeObjectURL(link.href)
  //   isExportLoading.value = false
  // })
}
</script>

<style scoped lang="scss"></style>
