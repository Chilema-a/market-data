import { nextTick, onBeforeUnmount, watch } from 'vue'
import type { Ref } from 'vue'
import { createHeaderWidthFitter, HeaderColumn } from '@/utils/table-header-width'

interface HeaderFitTable {
  store: {
    states: { originColumns: { value: HeaderColumn[] } }
  }
  doLayout: () => void
}

interface Controller {
  schedule: () => void
  stop: () => void
}

function observeTable(element: HTMLElement, table: HeaderFitTable): Controller {
  const fit = createHeaderWidthFitter()
  let frame = 0
  let stopped = false
  const header = element.querySelector<HTMLElement>('.el-table__header-wrapper')
  const mutationObserver = new MutationObserver(() => schedule())
  const observeHeader = () => {
    if (header)
      mutationObserver.observe(header, {
        childList: true,
        subtree: true,
        characterData: true,
        attributes: true,
        attributeFilter: ['style', 'width'],
      })
  }

  const measure = () => {
    frame = 0
    if (stopped || !header || !element.getBoundingClientRect().width) return
    mutationObserver.disconnect()
    try {
      const cells = Array.from(header.querySelectorAll<HTMLElement>('th.el-table__cell'))
      const changed = fit(table.store.states.originColumns.value, (column) => {
        const cell = cells.find((item) => item.classList.contains(column.id))
        const content = cell?.querySelector<HTMLElement>(':scope > .cell')
        if (!cell || !content) return 0

        // Measure actual fonts, custom headers, padding and sorting controls without
        // allowing the current constrained column width to affect the result.
        const probe = content.cloneNode(true) as HTMLElement
        Object.assign(probe.style, {
          position: 'fixed',
          left: '0',
          top: '-10000px',
          width: 'max-content',
          minWidth: '0',
          maxWidth: 'none',
          height: 'auto',
          visibility: 'hidden',
          pointerEvents: 'none',
        })
        cell.appendChild(probe)
        try {
          return Math.ceil(probe.getBoundingClientRect().width) + 2
        } finally {
          probe.remove()
        }
      })
      if (changed) table.doLayout()
    } finally {
      observeHeader()
    }
  }

  const schedule = () => {
    if (!stopped && !frame) frame = requestAnimationFrame(measure)
  }
  const resizeObserver = new ResizeObserver(schedule)
  resizeObserver.observe(element)
  observeHeader()
  document.fonts?.addEventListener('loadingdone', schedule)
  schedule()

  return {
    schedule,
    stop() {
      stopped = true
      cancelAnimationFrame(frame)
      resizeObserver.disconnect()
      mutationObserver.disconnect()
      document.fonts?.removeEventListener('loadingdone', schedule)
    },
  }
}

/** Bind either an existing table ref or callback refs for nested/expanded tables. */
export default function useTableHeaderFit(tableRef?: Ref<any>) {
  const controllers = new Map<HTMLElement, Controller>()
  const bind = (table: any) => {
    const element = table?.$el as HTMLElement | undefined
    if (element && table.store && table.doLayout) {
      if (!controllers.has(element)) controllers.set(element, observeTable(element, table))
      controllers.get(element)?.schedule()
    } else {
      nextTick(() => {
        controllers.forEach((controller, element) => {
          if (!element.isConnected) {
            controller.stop()
            controllers.delete(element)
          }
        })
      })
    }
  }
  if (tableRef) watch(tableRef, bind, { flush: 'post' })
  onBeforeUnmount(() => {
    controllers.forEach((controller) => controller.stop())
    controllers.clear()
  })
  return bind
}
