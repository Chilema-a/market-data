import { i18n } from '@/global/register-i18n'
import { App } from 'vue'

function registerGlobalProperties(app: App) {
  app.config.globalProperties.$filters = {
    showStatus(enable: boolean) {
      return enable ? t('enabled') : t('disable')
    },
  }
}

const t = i18n.global.t

export default registerGlobalProperties
