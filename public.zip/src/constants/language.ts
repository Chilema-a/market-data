export enum LANGUAGE_SERVER_DICT {
  CN = 'zh-CN',
  TW = 'zh-TW',
  US = 'en-US',
}

export enum LANGUAGE_LOCAL_DICT {
  CN = 'cn',
  TW = 'hk',
  US = 'us',
}

export const LANGUAGE_SERVER_MAP: Record<string, string> = {
  [LANGUAGE_SERVER_DICT.CN]: LANGUAGE_LOCAL_DICT.CN,
  [LANGUAGE_SERVER_DICT.TW]: LANGUAGE_LOCAL_DICT.TW,
  [LANGUAGE_SERVER_DICT.US]: LANGUAGE_LOCAL_DICT.US,
}

export const LANGUAGE_LOCAL_MAP: Record<string, string> = {
  [LANGUAGE_LOCAL_DICT.CN]: LANGUAGE_SERVER_DICT.CN,
  [LANGUAGE_LOCAL_DICT.TW]: LANGUAGE_SERVER_DICT.TW,
  [LANGUAGE_LOCAL_DICT.US]: LANGUAGE_SERVER_DICT.US,
}

export const normalizeLanguage = (language?: string | null): LANGUAGE_LOCAL_DICT => {
  const normalized = (language || '').replace('_', '-').toLowerCase()
  if (['us', 'en', 'en-us'].includes(normalized)) return LANGUAGE_LOCAL_DICT.US
  if (['hk', 'tw', 'zh-hk', 'zh-tw'].includes(normalized)) return LANGUAGE_LOCAL_DICT.TW
  return LANGUAGE_LOCAL_DICT.CN
}

// Only expose languages enabled by the server; local dictionaries provide translations.
export const getUiLanguageList = (config?: unknown): string[][] => {
  let source = config
  if (typeof source === 'string') {
    try {
      source = JSON.parse(source)
    } catch {
      source = undefined
    }
  }
  const list = Array.isArray(source) ? source : []
  const supported = list.filter(
    (item): item is string[] =>
      Array.isArray(item) &&
      typeof item[0] === 'string' &&
      typeof item[1] === 'string' &&
      Boolean(LANGUAGE_SERVER_MAP[item[0]])
  )
  return [...new Map(supported.map((item) => [item[0], [...item]])).values()]
}
