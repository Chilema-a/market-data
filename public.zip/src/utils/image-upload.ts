import { ElMessage, ElMessageBox } from 'element-plus'
import { i18n } from '@/global/register-i18n'
import 'element-plus/es/components/message-box/style/css'
import { uploadFileSys } from '@/api/quotation/quotation'

const t = i18n.global.t

export function useImageUploader() {
  const uploadImage = async (file: any) => {
    try {
      const fileSuffix = file.name.substring(file.name.lastIndexOf('.') + 1)

      const whiteList = ['jpeg', 'jpg', 'gif', 'png']
      if (!whiteList.includes(fileSuffix)) {
        ElMessage.warning(t('unsupported_file_format'))
        return null
      }

      const isLt2M = file.size / 1024 / 1024 < 2
      if (!isLt2M) {
        ElMessage.warning(t('file_size_exceeded'))
        return null
      }

      const formData = new FormData()
      formData.append('code', '1')
      formData.append('file', file.raw)

      const res = await uploadFileSys(formData)
      return res.data.result.url
    } catch (error) {
      ElMessageBox.alert(t('upload_retry'), i18n.global.t('tip'), {
        confirmButtonText: i18n.global.t('determine'),
        type: 'error',
      })
      return null
    }
  }

  return {
    uploadImage,
  }
}
