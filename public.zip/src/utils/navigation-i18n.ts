import { i18n } from '@/global/register-i18n'

const titleKeys = new Map<string, string>()
for (const locale of ['cn', 'hk', 'us']) {
  const titles = i18n.global.getLocaleMessage(locale).navigation || {}
  for (const [key, title] of Object.entries(titles)) {
    titleKeys.set(String(title), `navigation.${key}`)
  }
}

// Translate known navigation labels while preserving custom names from the server.
export const translateNavigation = (title = ''): string => {
  const key = titleKeys.get(title)
  return key ? i18n.global.t(key) : title
}
