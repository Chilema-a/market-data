/* eslint-disable guard-for-in */
import axios from 'axios'
import { SHA256 } from 'crypto-js'
import { ElMessageBox } from 'element-plus'
import 'element-plus/es/components/message-box/style/css'
import _ from 'lodash'
import { appStore } from '@/store'
import { i18n } from '@/global/register-i18n'
const t = i18n.global.t

/**
 * 国际化映射
 * @returns
 */
export const languageMapping: Record<string, string> = {
  cn: 'zh-CN',
  hk: 'zh-TW',
  us: 'en-US',
}

/**
 * 时间固定格式转换
 * @param timeArr
 * @returns
 */
export function dateFormat(timeArr: [Date, Date]) {
  return timeArr.map((v) => {
    let str = v.toJSON()
    str = str.replace('T', ' ')
    return str.slice(0, str.lastIndexOf('.'))
  })
}

/**
 * 查询参数过滤空值 ---- 待优化
 * @param data
 * @returns
 */
export function formToParams(data: Record<string, any> | undefined): Record<string, any> {
  const params: Record<string, any> = {}
  if (!data) return params

  // eslint-disable-next-line no-restricted-syntax
  for (const key in data) {
    if (['boolean', 'number'].includes(typeof data[key])) {
      params[key] = data[key]
      // eslint-disable-next-line no-continue
      continue
    }
    if (data[key] && data[key] !== '') {
      if (data[key] instanceof Array) {
        if (data[key].length) params[key] = data[key]
        // eslint-disable-next-line no-continue
        continue
      }

      params[key] = data[key]
    }
  }

  return params
}

/**
 * 文件流转blob下载
 */
export function fileDownload(file: Buffer, fileName: string): void {
  const blob = new Blob([file])
  const a = document.createElement('a')
  const url = URL.createObjectURL(blob)
  a.href = url
  a.download = fileName
  a.click()
  URL.revokeObjectURL(url)
}

/** get 导出文件 */
export function exportFile(
  baseUrl: string,
  path: string,
  data: Record<string, any>,
  fileName = (t('table_data') + '.xls') as string
) {
  const aParams = formToParams(data)
  const aParamsStr = Object.keys(aParams).reduce((pre: string, val: any) => {
    const paramsValue = aParams[val]
    if (paramsValue instanceof Array) {
      const result = paramsValue
        .map((item: any, index: number) => {
          if (typeof item !== 'object') {
            return `${val}=${item}&`
          }

          const keys = Object.keys(item).reduce(
            (pre: string, key: string) => (pre += `${val}[${index}].${key}=${item[key]}&`),
            ''
          )
          return keys
        })
        .join('')

      pre += result
      return pre
    }

    pre += `${val}=${aParams[val]}&`
    return pre
  }, '?')

  const url = `${baseUrl}${path}${encodeURI(
    aParamsStr ? aParamsStr.substring(0, aParamsStr.length - 1) : ''
  )}`

  return new Promise((resolve) => {
    axios(url, {
      headers: {
        method: 'GET',
        token: appStore().token,
        'Accept-Language': languageMapping[appStore().language] || languageMapping.cn,
      },
      responseType: 'blob',
    })
      .then((res: Record<string, any>) => {
        if (res.data.code) {
          ElMessageBox.alert(res.data.message, t('tip'), {
            confirmButtonText: t('determine'),
            type: 'error',
          })
          return
        }
        fileDownload(res.data, fileName)
      })
      .catch(() => {
        ElMessageBox.alert(t('export_failed'), t('tip'), {
          confirmButtonText: t('determine'),
          type: 'error',
        })
      })
      .finally(() => {
        resolve('')
      })
  })
}

export function perfectI18nArray(
  arr?: [],
  templateData = {
    name: '',
    remark: '',
    path: '',
  }
) {
  const { languageList = [] } = appStore()
  if (arr && arr.length) {
    const newArr = arr.map((item) => {
      const obj = { ...item }
      return obj
    })
    //  填充默认值
    languageList.forEach((item: string[]) => {
      const lang = item[0]
      if (!newArr.find((item: any) => item.lang === lang)) {
        const obj = {
          lang,
          ...templateData,
        }
        newArr.push(obj)
      }
    })
    return newArr
  }

  if (languageList.length) {
    const resultArr = languageList.map((item: string[]) => {
      return {
        lang: item[0],
        ...templateData,
      }
    })
    return resultArr
  }

  return []
}

/**
 * 验证是否有未填项
 * @param original 原数据
 * @param current 当前数据
 * @param path  属性路径
 * @returns {boolean} true: 有 false: 没有
 */
export function verifyI18ns(original: any, current: any, path = ''): boolean {
  if (_.isPlainObject(current)) {
    for (const key in current) {
      const currentPath = path ? `${path}.${key}` : key
      const result = verifyI18ns(original, current[key], currentPath)
      if (result) return true
    }

    return false
  }

  if (_.isArray(current)) {
    const result = current.find((item: any, index: number) => {
      const currentPath = path ? `${path}[${index}]` : `[${index}]`
      const result = verifyI18ns(original, item, currentPath)
      return result
    })

    return result !== undefined
  }

  if (_.get(original, path)) return false

  return true
}

/**
 * 填充数据
 * @param fill 需要填充的数据
 * @param current 被填充的数据
 * @param parentPath 属性路径
 * @returns
 */
export function fillData(fill: any, current: any, parentPath = '') {
  if (_.isPlainObject(current)) {
    for (const key in current) {
      const currentKey = parentPath ? `${parentPath}.${key}` : key
      fillData(fill, current[key], currentKey)
    }
    return
  }

  if (_.isArray(current)) {
    current.forEach((item: any, index: number) => {
      const currentPath = parentPath ? `${parentPath}[${index}]` : `[${index}]`
      fillData(fill, item, currentPath)
    })
    return
  }

  if (_.get(fill, parentPath)) return

  _.set(fill, parentPath, current)
}

/**
 * 数组遍历填充
 * @param arr
 * @returns
 */
function fillByArray(arr: Record<string, any>[]) {
  return arr.map((item) => {
    const cache = { ...item }
    const { lang } = cache

    if (lang === languageMapping.cn) {
      // 以繁体填充
      const hk = arr.find((item) => item.lang === languageMapping.hk) || {}
      const hkCache = { ...hk }

      fillData(cache, hkCache)
      return cache
    }

    // 以简体填充
    const cn = arr.find((item) => item.lang === languageMapping.cn) || {}
    const cnCache = { ...cn }

    fillData(cache, cnCache)
    return cache
  })
}

/**
 * 国际化数据填充
 * @param arr
 * @returns
 */
export function fillByI18ns(arr: Record<string, any>[]) {
  return new Promise((resolve, reject) => {
    const resultArr = verifyI18ns(arr, arr)
    if (!resultArr) {
      return resolve('')
    }

    ElMessageBox.confirm(t('internationalization_tips'), {
      confirmButtonText: t('determine'),
      cancelButtonText: t('cancel'),
      type: 'warning',
    })
      .then(() => {
        const result = fillByArray(arr)
        resolve(result)
      })
      .catch(() => {
        reject('')
      })
  })
}
export function fillByI18nText(arr: Record<string, any>[]) {
  return new Promise((resolve, reject) => {
    const resultArr = verifyI18ns(arr, arr)
    if (!resultArr) {
      return resolve('')
    }

    ElMessageBox.confirm(t('reject_it'), {
      confirmButtonText: t('determine'),
      cancelButtonText: t('cancel'),
      type: 'warning',
    })
      .then(() => {
        const result = fillByArray(arr)
        resolve(result)
      })
      .catch(() => {
        reject('')
      })
  })
}

export function downloadFile(filePath: string, fileName: string) {
  axios({
    url: filePath,
    method: 'GET',
    responseType: 'blob',
    headers: {
      Authorization: 'Bearer ' + localStorage.getItem('token'),
    },
  }).then((res) => {
    const blob = new Blob([res.data])

    const link = document.createElement('a')
    link.href = window.URL.createObjectURL(blob)
    link.download = fileName || t('download_file')

    document.body.appendChild(link)
    link.click()

    document.body.removeChild(link)
    window.URL.revokeObjectURL(link.href)
  })
}

// 密码加密
export function passwordEncrypt(password: string) {
  return SHA256(password).toString().substring(0, 20)
}

// 密码加密（兼容 system 的 login 接口入参，login api 内部使用）
export function debounce(fn: any, delay: number) {
  let timer: any = null

  return function (...args: any[]) {
    if (timer) clearTimeout(timer)

    timer = setTimeout(() => {
      fn.apply(this, args)
    }, delay)
  }
}

/**
 * 填充国际化字段：未填语言的内容用第一种语言（简体）填充
 */
export function fillI18ns(arr: Record<string, string>[]) {
  return arr.map((v) => {
    const cache: Record<string, string> = { ...v }
    Object.keys(v).forEach((key: string) => {
      if (!v[key]) {
        cache[key] = arr[0][key]
      }
    })

    return cache
  })
}
