import { i18n } from '@/global/register-i18n'

const HTTP_STATUS: Record<number, string> = {
  '200': 'http_success',
  '201': 'http_created',
  '202': 'http_accepted',
  '400': 'http_bad_request',
  '401': 'http_unauthorized',
  '403': 'http_forbidden',
  '404': 'http_not_found',
  '500': 'http_server_error',
  '502': 'http_bad_gateway',
  '503': 'http_unavailable',
  '504': 'http_gateway_timeout',
}

export const getHttpStatusText = function (code: number, err?: any): string {
  if (err && err.response && err.response.status) {
    code = err.response.status
  }
  if (HTTP_STATUS[code]) return i18n.global.t(HTTP_STATUS[code])
  if (typeof err === 'string' && err.indexOf('timeout') > -1) {
    return i18n.global.t('http_timeout')
  }
  if (typeof err === 'string' && err.indexOf('Network') > -1) {
    return i18n.global.t('http_network_error')
  }
  return i18n.global.t('http_unknown_error')
}
