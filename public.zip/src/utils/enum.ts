import { i18n } from '@/global/register-i18n'

// 订购人
export const subTypeSelect = [
  {
    get label() {
      return i18n.global.t('system')
    },
    value: '0',
  },
  {
    get label() {
      return i18n.global.t('customer')
    },
    value: '1',
  },
  {
    get label() {
      return i18n.global.t('admin')
    },
    value: '2',
  },
]

// 生效状态
export const enableStatusSelect = [
  {
    get label() {
      return i18n.global.t('executed')
    },
    value: '1',
  },
  {
    get label() {
      return i18n.global.t('pending_effect')
    },
    value: '2',
  },
  {
    get label() {
      return i18n.global.t('expired')
    },
    value: '5',
  },
  {
    get label() {
      return i18n.global.t('invalid')
    },
    value: '3',
  },
  {
    get label() {
      return i18n.global.t('empty')
    },
    value: '4',
  },
]

// 审核状态
export const statusSelect = [
  {
    get label() {
      return i18n.global.t('reject')
    },
    value: 'REJECT',
  },
  {
    get label() {
      return i18n.global.t('check_pending')
    },
    value: 'REVIEW_ING',
  },
  {
    get label() {
      return i18n.global.t('audit_approve')
    },
    value: 'SUCCESS',
  },
]
// 是否赠送
export const isGiveSelect = [
  {
    get label() {
      return i18n.global.t('yes')
    },
    value: 'true',
  },
  {
    get label() {
      return i18n.global.t('no')
    },
    value: 'false',
  },
]
