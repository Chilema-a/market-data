export interface HeaderColumn {
  id: string
  type?: string
  width?: string | number | null
  minWidth?: string | number | null
  children?: HeaderColumn[]
}

interface OriginalWidth {
  width: HeaderColumn['width']
  minWidth: HeaderColumn['minWidth']
  appliedWidth: HeaderColumn['width']
  appliedMinWidth: HeaderColumn['minWidth']
}

const numericWidth = (width: HeaderColumn['width']) => parseFloat(String(width)) || 0

/** Retain configured widths as a floor; recalculate from that floor on language changes. */
export function createHeaderWidthFitter() {
  const originals = new WeakMap<HeaderColumn, OriginalWidth>()

  return (columns: HeaderColumn[], measure: (column: HeaderColumn) => number): boolean => {
    let changed = false
    const targets = new Map<HeaderColumn, { property: 'width' | 'minWidth'; width: number }>()
    const fit = (column: HeaderColumn): number => {
      if (column.children?.length) {
        const total = column.children.reduce((sum, child) => sum + fit(child), 0)
        const required = measure(column)
        if (required > total) {
          // A grouped title must also fit across the widths of its leaf columns.
          let last = column.children[column.children.length - 1]
          while (last.children?.length) last = last.children[last.children.length - 1]
          const target = targets.get(last)
          if (target) target.width += required - total
        }
        return Math.max(total, required)
      }

      if (column.type === 'selection' || column.type === 'expand') {
        return numericWidth(column.width) || numericWidth(column.minWidth) || 48
      }

      let original = originals.get(column)
      if (!original) {
        original = {
          width: column.width,
          minWidth: column.minWidth,
          appliedWidth: column.width,
          appliedMinWidth: column.minWidth,
        }
        originals.set(column, original)
      } else {
        // Respect explicit prop updates and manual column resizing.
        if (column.width !== original.appliedWidth) original.width = column.width
        if (column.minWidth !== original.appliedMinWidth) original.minWidth = column.minWidth
      }

      const property = numericWidth(original.width) ? 'width' : 'minWidth'
      const minimum = numericWidth(original.width) || numericWidth(original.minWidth) || 80
      const nextWidth = Math.max(minimum, Math.ceil(measure(column)))
      targets.set(column, { property, width: nextWidth })
      return nextWidth
    }

    columns.forEach(fit)
    targets.forEach(({ property, width }, column) => {
      if (numericWidth(column[property]) !== width) {
        column[property] = width
        changed = true
      }
      const original = originals.get(column) as OriginalWidth
      original.appliedWidth = column.width
      original.appliedMinWidth = column.minWidth
    })
    return changed
  }
}
