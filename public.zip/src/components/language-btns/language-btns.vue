<template>
  <div v-if="languageList.length" class="language-btns">
    <span
      v-for="item of languageList"
      :key="item.value"
      :class="['lan', currentLang === item.value ? 'active' : '']"
      @click="handleClick(item)"
      >{{ item.label }}</span
    >
  </div>
</template>
<script lang="ts">
import { computed, defineComponent } from 'vue'
import { useI18n } from 'vue-i18n'
import { getUiLanguageList, LANGUAGE_SERVER_MAP } from '@/constants/language'
import { useAppStore } from '@/store'

export default defineComponent({
  name: 'LanguageBtns',
  emits: ['btnClick'],
  setup(_props, { emit }) {
    const appStore = useAppStore()
    const { t, te } = useI18n({ useScope: 'global' })
    const languageList = computed(() =>
      getUiLanguageList(appStore.languageList).map((item) => ({
        label: te(item[0]) ? t(item[0]) : item[1],
        value: LANGUAGE_SERVER_MAP[item[0]],
      }))
    )
    const currentLang = computed(() => appStore.language)

    const handleClick = (lan: { label: string; value: string }) => {
      appStore.setLanguage(lan.value)
      emit('btnClick', lan.value)
    }

    return { languageList, currentLang, handleClick }
  },
})
</script>
<style lang="scss" scoped>
.language-btns {
  height: auto;
  min-height: 36px;
  max-width: 100%;
  display: inline-flex;
  flex-wrap: wrap;
  background: #f5f5f5;
  border-radius: 4px;
  padding: 2px;
  float: right;
  margin-top: -20px;
  .lan {
    display: inline-block;
    min-width: 36px;
    flex: 0 0 auto;
    padding: 0 8px;
    box-sizing: border-box;
    height: 32px;
    line-height: 32px;
    white-space: nowrap;
    font-family: PingFangSC-Regular;
    font-weight: 400;
    font-size: 14px;
    color: #999999;
    cursor: pointer;
    &:not(:last-of-type) {
      position: relative;
      &::after {
        content: '';
        position: absolute;
        width: 1px;
        height: 16px;
        right: 0;
        transform: translateY(-50%);
        top: 50%;
        background-color: #ebebeb;
      }
    }
    &.active {
      background: #ffffff;
      box-shadow: 0 0 8px 0 #d8d8d8;
      border-radius: 4px;
      // padding: 2px;
    }
  }
}
</style>
