<template>
  <div class="custom-dialog-footer">
    <slot></slot>
  </div>
</template>

<style lang="scss" scoped>
.custom-dialog-footer {
  max-width: 100%;
  padding-top: var(--dialog-footer-gap, 24px);
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: var(--ui-control-gap);

  /* stylelint-disable-next-line selector-pseudo-class-no-unknown -- Vue scoped selector. */
  :deep(.el-button + .el-button) {
    margin-left: 0;
  }
}
</style>
