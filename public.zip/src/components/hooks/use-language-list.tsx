import { computed } from 'vue'
import { useAppStore } from '@/store'

export const useLanguageList = () => {
  const appStore = useAppStore()
  const languageList = computed(() => appStore.languageList || [])
  return languageList
}
