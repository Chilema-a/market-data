import { tableSlot } from '@/utils/table-ui'
import useTableViewport from '@/hooks/useTableViewport'
import useTableHeaderFit from '@/hooks/useTableHeaderFit'
import { computed, defineComponent, ref } from 'vue'
import type { PropType } from 'vue'
import { useI18n } from 'vue-i18n'
import { ElTable, ElTableColumn, ElPagination } from 'element-plus'
import type { PaginationProps, TableColumnCtx, TableInstance, TableProps } from 'element-plus'

type TableRow = Record<string, any>
type EventHandlers = Record<string, (...args: any[]) => void>

interface ColumnConfig extends Partial<TableColumnCtx<TableRow>> {
  slot?: string
}

interface TableConfig {
  tableProps?: Partial<TableProps<TableRow>>
  tableEvent?: EventHandlers
  customColumns?: ColumnConfig[]
}

interface PaginationConfig {
  paginationProps?: Partial<PaginationProps> & Record<string, unknown>
  paginationEvent?: EventHandlers
}

const formatCell: TableColumnCtx<TableRow>['formatter'] = (_row, _column, value) =>
  value === null || value === undefined || value === '' ? '--' : value

export default defineComponent({
  name: 'BaseTable',
  props: {
    config: {
      type: Object as PropType<TableConfig>,
      default: () => ({}),
    },
    pagination: {
      type: [Object, Boolean] as PropType<PaginationConfig | false | null>,
      default: undefined,
    },
    isTableLoading: {
      type: Boolean,
      default: false,
    },
    isLoading: {
      type: Boolean,
      default: false,
    },
    height: {
      type: [String, Number],
      default: 550,
    },
  },
  setup(props, { slots, expose }) {
    const { t } = useI18n()
    const loading = computed(() => props.isTableLoading || props.isLoading)
    const pagination = computed(() => props.pagination || undefined)
    const currentPage = ref(1)
    const pageSize = ref(20)
    const baseTable = ref<TableInstance>()
    useTableHeaderFit(baseTable)
    const viewportHeight = useTableViewport(baseTable, () => Boolean(pagination.value))

    const toFirstPage = () => {
      currentPage.value = 1
    }

    expose({
      toFirstPage,
      baseTable,
    })

    return () => (
      <>
        <ElTable
          ref={baseTable}
          empty-text={loading.value ? ' ' : t('temporarily_no_data')}
          v-loading={loading.value}
          border
          {...props.config.tableProps}
          {...props.config.tableEvent}
          show-overflow-tooltip
          height={viewportHeight.value ?? props.config.tableProps?.height ?? props.height}
          stripe
        >
          {(props.config.customColumns ?? []).map((column, columnIndex) => {
            if (column.slot) return tableSlot(slots[column.slot]?.(), column.slot)
            return (
              <ElTableColumn
                align="center"
                {...column}
                key={column.columnKey ?? column.prop ?? columnIndex}
                formatter={column.formatter ?? formatCell}
              />
            )
          })}
        </ElTable>

        {pagination.value && (
          <ElPagination
            background
            pager-count={7}
            v-model:currentPage={currentPage.value}
            page-sizes={[20, 50, 100, 200]}
            v-model:pageSize={pageSize.value}
            layout="total, sizes, prev, pager, next, jumper"
            total={0}
            {...pagination.value.paginationProps}
            {...pagination.value.paginationEvent}
            class="ui-table-pagination"
          />
        )}
      </>
    )
  },
})
