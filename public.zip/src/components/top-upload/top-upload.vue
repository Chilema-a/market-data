<template>
  <el-dialog
    v-model="isShowDialog"
    :title="$t('import_data')"
    width="800px"
    center
    @close="closeHandle"
  >
    <div style="text-align: center">
      <div class="upload-actions">
        <el-upload
          ref="uploadCustomersRef"
          class="upload-demo"
          :action="uploadUrl"
          :headers="uploadHeader"
          :limit="1"
          :auto-upload="false"
          :on-success="uploadCustomerSuccess"
        >
          <template #trigger>
            <el-button type="primary">{{ $t('bulk_import') }}</el-button>
          </template>
        </el-upload>
        <el-link type="primary" @click="toDownloadTemplate">{{ $t('download_template') }}</el-link>
      </div>
      <div>
        {{ $t('uploading_file_prompt', 0) }}
        <el-link type="primary" @click="toFileImportlog">{{
          $t('uploading_file_prompt', 1)
        }}</el-link>
        {{ $t('uploading_file_prompt', 2) }}
      </div>
    </div>
    <template #footer>
      <el-button @click="uploadNewCustomers">{{ $t('confirm_upload') }}</el-button>
    </template>
  </el-dialog>
</template>
<script lang="ts">
import { defineComponent, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import { useI18n } from 'vue-i18n'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useAppStore } from '@/store'

export default defineComponent({
  name: 'TopUpload',
  props: {
    action: String,
    isShowUploadDialog: Boolean,
    importLogUrl: {
      type: String,
      default: () => '',
    },
    downloadTemplate: {
      type: Function,
      default: () => {},
    },
  },
  emits: ['update:isShowUploadDialog'],
  setup(props, { emit }) {
    const { t } = useI18n()
    const appStore = useAppStore()
    const isShowDialog = ref(false)
    const uploadCustomersRef = ref()
    const uploadHeader: any = {
      token: appStore.token,
    }
    const router = useRouter()
    const uploadCustomerSuccess = (response: any) => {
      if (response.success) {
        ElMessage.success(t('upload_success'))
        isShowDialog.value = false
      } else {
        ElMessageBox.alert(t('upload_failed'), t('tip'), {
          confirmButtonText: t('determine'),
          type: 'error',
        })
      }
      uploadCustomersRef.value.clearFiles()
    }
    const uploadNewCustomers = () => {
      uploadCustomersRef.value.submit()
    }
    const toDownloadTemplate = () => {
      props?.downloadTemplate()
    }
    const toFileImportlog = () => {
      router.push(props.importLogUrl)
    }
    const closeHandle = () => {
      emit('update:isShowUploadDialog')
    }

    watch(
      () => props.isShowUploadDialog,
      (newVal: boolean) => {
        if (newVal) isShowDialog.value = newVal
      }
    )
    return {
      isShowDialog,
      uploadUrl: props.action || '',
      uploadCustomersRef,
      uploadHeader,
      uploadCustomerSuccess,
      uploadNewCustomers,
      toDownloadTemplate,
      toFileImportlog,
      closeHandle,
    }
  },
})
</script>

<style lang="scss" scoped>
.upload-actions {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: center;
  gap: var(--ui-gap);
  margin-bottom: 20px;

  .upload-demo {
    max-width: min(240px, 100%);
  }

  .el-link {
    min-height: var(--ui-control-height);
  }
}
</style>
