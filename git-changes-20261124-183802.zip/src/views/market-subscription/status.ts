import type { TagProps } from 'element-plus'
import { AuditStatus, EnableStatus, OrderEnableStatus } from '@/types/quotationType'

const statusTypes: Record<string, TagProps['type']> = {
  [EnableStatus.Enable]: 'success',
  [EnableStatus.Disable]: 'info',
  [EnableStatus.Failure]: 'info',
  [OrderEnableStatus.PendingPay]: 'warning',
  [OrderEnableStatus.PayFail]: 'danger',
  [OrderEnableStatus.Pending]: 'primary',
  [OrderEnableStatus.Effective]: 'success',
  [OrderEnableStatus.Failure]: 'info',
  [AuditStatus.ReviewIng]: 'warning',
  [AuditStatus.Reject]: 'danger',
  [AuditStatus.Success]: 'success',
  [AuditStatus.DisableReviewIng]: 'warning',
  [AuditStatus.DisableReject]: 'danger',
  [AuditStatus.DisableSuccess]: 'success',
}

export function getQuotationStatusType(status?: string | null): TagProps['type'] {
  return (status && statusTypes[status]) || 'info'
}
