import { AuditStatus, EnableStatus } from '../../../../types/quotationType'

export function getPackageActions({ status, enable }: { status: string; enable: string }) {
  const disableReview = status === AuditStatus.DisableReviewIng
  const disableRejected = status === AuditStatus.DisableReject
  const disableApproved = status === AuditStatus.DisableSuccess
  const disableFlow = disableReview || disableRejected || disableApproved

  return {
    modify: status !== AuditStatus.Success && !disableFlow,
    changeEnable:
      !disableFlow ||
      (disableRejected && enable === EnableStatus.Enable) ||
      (disableApproved && enable === EnableStatus.Disable),
    review: disableReview || status === AuditStatus.ReviewIng,
    disableReview,
  }
}
