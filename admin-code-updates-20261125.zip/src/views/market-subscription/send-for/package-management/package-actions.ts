import { AuditStatus, EnableStatus } from '../../../../types/quotationType'

export function getPackageActions({
  status,
  enable,
  canReview,
}: {
  status: string
  enable: string
  canReview?: boolean
}) {
  const disableReview = status === AuditStatus.DisableReviewIng
  const disableRejected = status === AuditStatus.DisableReject
  const disableApproved = status === AuditStatus.DisableSuccess
  const disableFlow = disableReview || disableRejected || disableApproved

  return {
    modify: status !== AuditStatus.Success && !disableFlow,
    changeEnable:
      !disableFlow ||
      (disableRejected && enable === EnableStatus.Enable) ||
      (disableApproved && enable === EnableStatus.Disable),
    review: canReview === true,
    disableReview,
  }
}
