<template>
  <el-dialog
    v-model="visible"
    :title="$t(mode === 'review' ? 'package_disable_review' : 'package_disable_title')"
    width="min(560px, calc(100vw - 32px))"
    destroy-on-close
    :close-on-click-modal="false"
    :show-close="!submitting"
    :close-on-press-escape="!submitting"
    @close="requestId++"
  >
    <el-skeleton v-if="loading" :rows="6" animated />
    <el-empty v-else-if="loadError" :description="$t('request_failed')">
      <el-button @click="loadData">{{ $t('retry') }}</el-button>
    </el-empty>
    <template v-else-if="loaded">
      <el-alert
        v-if="mode === 'apply'"
        class="disable-tip"
        :title="$t('package_disable_tip')"
        type="warning"
        :closable="false"
      />
      <el-form class="disable-form" label-width="auto" label-position="right">
        <el-form-item class="form-text-item" :label="$t('immediate_cancel_package') + '：'">
          {{ packageInfo.rtq }}-{{ packageInfo.packageName }}
        </el-form-item>
        <template v-if="mode === 'review'">
          <el-form-item class="form-text-item" :label="$t('package_disable_applicant') + '：'">
            {{ packageInfo.lastSubmitUser || '--' }}
          </el-form-item>
          <el-form-item class="form-text-item" :label="$t('package_disable_reason') + '：'">
            {{ reasonLabel }}
          </el-form-item>
          <el-form-item class="form-text-item" :label="$t('cancel_remark') + '：'">
            <span class="remark-text">{{ form.disableRemark || '--' }}</span>
          </el-form-item>
          <el-form-item :label="$t('audit_status') + '：'" required>
            <el-radio-group v-model="isPass" :disabled="submitting">
              <el-radio :label="true">{{ $t('audit_approve') }}</el-radio>
              <el-radio :label="false">{{ $t('audit_reject') }}</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item :label="$t('review_reason') + '：'">
            <el-input
              v-model="reviewReason"
              :placeholder="$t('review_reason_placeholder')"
              type="textarea"
              :rows="4"
              maxlength="200"
              show-word-limit
              :disabled="submitting"
            />
          </el-form-item>
        </template>
        <template v-else>
          <el-form-item :label="$t('package_disable_reason') + '：'" required>
            <el-select
              v-model="form.disableReason"
              :placeholder="$t('please_select')"
              :disabled="submitting"
            >
              <el-option
                v-for="item in reasons"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item :label="$t('cancel_remark') + '：'">
            <el-input
              v-model="form.disableRemark"
              type="textarea"
              :rows="4"
              maxlength="200"
              show-word-limit
              :disabled="submitting"
              :placeholder="$t('cancel_remark_placeholder')"
            />
          </el-form-item>
        </template>
        <el-form-item
          v-if="mode === 'apply' && packageInfo.reviewReason"
          class="form-text-item"
          :label="$t('order_reject_reason') + '：'"
        >
          <span class="remark-text reject-reason">{{ packageInfo.reviewReason }}</span>
        </el-form-item>
      </el-form>
    </template>
    <template #footer>
      <CustomDialogFooter>
        <el-button
          class="disable-action"
          type="primary"
          :loading="submitting"
          :disabled="!canSubmit"
          @click="submit"
        >
          {{ $t(mode === 'review' ? 'determine' : 'exchange_submit_review') }}
        </el-button>
        <el-button class="disable-action" :disabled="submitting" @click="visible = false">
          {{ $t('cancel') }}
        </el-button>
      </CustomDialogFooter>
    </template>
  </el-dialog>
</template>

<script setup lang="ts">
import { computed, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { useI18n } from 'vue-i18n'
import CustomDialogFooter from '@/components/custom-dialog-footer.vue'
import { fetchDicts } from '@/api-v2/quotation/query'
import { applyPackageDisable, reviewPackageDisable } from '@/api-v2/quotation/mutations'

export interface DisablePackageInfo {
  packageId: string
  rtq: string
  packageName: string
  lastSubmitUser?: string
  disableReason?: string
  disableRemark?: string
  reviewReason?: string
}

const emit = defineEmits<{ (e: 'callback'): void }>()
const { t } = useI18n()
const visible = ref(false)
const loading = ref(false)
const loaded = ref(false)
const loadError = ref(false)
const submitting = ref(false)
const mode = ref<'apply' | 'review'>('apply')
const packageInfo = ref<DisablePackageInfo>({ packageId: '', rtq: '', packageName: '' })
const reasons = ref<{ value: string; label: string }[]>([])
const form = reactive({ disableReason: '', disableRemark: '' })
const isPass = ref<boolean | null>(null)
const reviewReason = ref('')
const reasonLabel = computed(
  () =>
    reasons.value.find((item) => item.value === form.disableReason)?.label ||
    form.disableReason ||
    '--'
)
const canSubmit = computed(
  () =>
    loaded.value &&
    !loading.value &&
    !loadError.value &&
    (mode.value === 'review'
      ? isPass.value !== null
      : reasons.value.some((item) => item.value === form.disableReason))
)
let requestId = 0
let currentLoader: (() => Promise<DisablePackageInfo>) | undefined

function open(nextMode: 'apply' | 'review', loader: () => Promise<DisablePackageInfo>) {
  if (submitting.value) return
  mode.value = nextMode
  currentLoader = loader
  form.disableReason = ''
  form.disableRemark = ''
  isPass.value = null
  reviewReason.value = ''
  reasons.value = []
  visible.value = true
  loadData()
}

async function loadData() {
  if (!currentLoader) return
  const id = ++requestId
  loading.value = true
  loaded.value = false
  loadError.value = false
  try {
    const [dict, detail] = await Promise.all([
      fetchDicts(['package_disable_reason']),
      currentLoader(),
    ])
    if (id !== requestId) return
    reasons.value = (dict.result?.package_disable_reason || []).map(([value, label]) => ({
      value,
      label,
    }))
    packageInfo.value = detail
    form.disableReason = detail.disableReason || ''
    form.disableRemark = detail.disableRemark || ''
    loaded.value = true
  } catch {
    if (id === requestId) loadError.value = true
  } finally {
    if (id === requestId) loading.value = false
  }
}

async function submit() {
  if (submitting.value || !canSubmit.value) return
  if (
    (mode.value === 'apply' && form.disableRemark.length > 200) ||
    (mode.value === 'review' && reviewReason.value.length > 200)
  ) {
    ElMessage.warning(t('reason_length_limit'))
    return
  }
  submitting.value = true
  try {
    if (mode.value === 'review') {
      await reviewPackageDisable({
        packageId: packageInfo.value.packageId,
        isPass: isPass.value as boolean,
        reviewReason: reviewReason.value,
      })
    } else {
      await applyPackageDisable({
        packageId: packageInfo.value.packageId,
        disableReason: form.disableReason,
        remark: form.disableRemark,
      })
    }
    visible.value = false
    ElMessage.success(t('operation_success'))
    emit('callback')
  } catch {
    // 接口错误由统一请求拦截器提示，保留输入以便重试。
  } finally {
    submitting.value = false
  }
}

defineExpose({ open })
</script>

<style scoped>
.disable-form {
  --ui-control-width: 100%;
}

.disable-action {
  width: 140px;
  max-width: 100%;
}

.remark-text {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

.reject-reason {
  color: var(--el-color-danger);
}

.disable-tip {
  margin-bottom: 16px;
}
</style>
